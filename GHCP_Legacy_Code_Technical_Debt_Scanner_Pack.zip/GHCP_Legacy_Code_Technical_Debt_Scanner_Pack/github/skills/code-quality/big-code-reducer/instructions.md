# Instructions

1. Scan full code, PR diff, or selected files.
2. Identify code quality risks.
3. Classify issues by severity.
4. Explain business and production impact.
5. Suggest safe refactoring.
6. Provide improved code examples.
7. Recommend test cases before refactoring.
8. Generate Jira-ready action items.