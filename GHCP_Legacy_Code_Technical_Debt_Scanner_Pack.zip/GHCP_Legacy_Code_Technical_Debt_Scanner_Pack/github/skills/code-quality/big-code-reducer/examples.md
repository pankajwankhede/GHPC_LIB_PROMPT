# Example Prompts

## Full Legacy Scan
Scan this project/code and identify legacy code, duplicate code, memory leak risks, big methods, poor exception handling, and refactoring opportunities.

## Duplicate Code
Find duplicate logic and suggest common utility/service extraction.

## Big Code Reduction
Review this large service class and split it into smaller maintainable classes.

## Memory Leak
Check this Java/React code for memory leaks and memory pressure risks.

## Exception Handling
Review this Spring Boot code for poor exception handling and provide enterprise-grade fixes.

## Technical Debt Report
Generate an executive technical debt report from these code findings.