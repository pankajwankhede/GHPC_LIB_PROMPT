# Legacy Code Scanner Checklist

## Code Size
- [ ] Big classes detected
- [ ] Big methods detected
- [ ] Too many responsibilities detected

## Maintainability
- [ ] Duplicate code detected
- [ ] Dead code detected
- [ ] Poor naming detected
- [ ] Tight coupling detected

## Performance
- [ ] DB calls inside loops checked
- [ ] Remote calls inside loops checked
- [ ] Missing pagination checked
- [ ] Large memory processing checked

## Memory
- [ ] Static collection leaks checked
- [ ] ThreadLocal cleanup checked
- [ ] Resource closing checked
- [ ] Cache eviction checked

## Exception Handling
- [ ] Empty catch blocks checked
- [ ] Generic exceptions checked
- [ ] Stack trace exposure checked
- [ ] Safe error response checked

## Refactoring
- [ ] Tests recommended
- [ ] Safe migration plan added
- [ ] Priority assigned