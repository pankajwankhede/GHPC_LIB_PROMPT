# Technical Debt Severity Model

## Critical
Can cause outage, data leak, severe memory leak, or production failure.

## High
Major performance bottleneck, unmaintainable critical flow, unsafe exception handling.

## Medium
Duplicate logic, large method/class, weak testability, moderate refactoring needed.

## Low
Naming, formatting, minor cleanup, small duplication.