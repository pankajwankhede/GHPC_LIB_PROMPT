# Code Scan Output Template

## Executive Summary
## Critical Findings
## High Findings
## Medium Findings
## Low Findings
## Duplicate Code
## Big Code / Complexity
## Memory Leak Risks
## Time-Consuming Code
## Exception Handling Issues
## Refactoring Roadmap
## Jira Stories
## Final Score