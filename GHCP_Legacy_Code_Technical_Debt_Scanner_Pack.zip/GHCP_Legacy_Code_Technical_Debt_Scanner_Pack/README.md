# GHCP Legacy Code + Technical Debt Scanner Pack

This pack deeply scans code for:
- Legacy code
- Technical debt
- Big code/classes/methods
- Duplicate code
- Memory leaks
- Time-consuming logic
- Poor exception handling
- Performance bottlenecks
- Refactoring opportunities
- Modernization roadmap