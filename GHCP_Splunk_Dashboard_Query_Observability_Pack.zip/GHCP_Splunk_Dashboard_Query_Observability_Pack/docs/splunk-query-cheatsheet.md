# Splunk Query Cheatsheet

## Base Search
```spl
index=<index> sourcetype=<sourcetype> app=<app> env=<env>
```

## Errors
```spl
index=<index> app=<app> level=ERROR
| stats count by exception, endpoint
```

## Latency
```spl
index=<index> app=<app> durationMs=*
| timechart p95(durationMs) p99(durationMs)
```

## Correlation ID
```spl
index=<index> correlationId="<id>"
| sort _time
| table _time service level message
```