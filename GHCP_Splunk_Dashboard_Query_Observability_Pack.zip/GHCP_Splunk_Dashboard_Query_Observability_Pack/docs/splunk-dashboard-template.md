# Splunk Dashboard Template

## Dashboard Name
<Service> Production Health Dashboard

## Global Filters
- environment
- application
- service
- endpoint
- region
- time range

## Panels
1. Total Requests
2. Error Rate
3. P95 Latency
4. P99 Latency
5. Top Exceptions
6. Top Failing Endpoints
7. JVM Errors
8. Pod Restarts
9. Auth Failures
10. Business Transaction Failures