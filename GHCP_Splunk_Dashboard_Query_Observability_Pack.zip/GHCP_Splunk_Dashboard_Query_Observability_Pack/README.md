# GHCP Splunk Dashboard + Query Observability Pack

Deep enterprise prompts for Splunk SPL queries, dashboards, alerts, RCA, API/JVM/Kubernetes/auth monitoring, business KPIs, and field extraction.