# Kubernetes Dashboard Generator

## Goal
Create Splunk dashboards for Kubernetes production monitoring.

## Monitor
- Pod restarts
- CrashLoopBackOff
- OOMKilled
- CPU usage
- Memory usage
- Readiness/liveness failures
- Deployment rollout
- Node pressure
- Container errors
- Ingress errors

## Example SPL

### CrashLoop
```spl
index=<k8s_index> namespace=<namespace> ("CrashLoopBackOff" OR "Back-off restarting failed container")
| stats count by pod, container, namespace
| sort -count
```

### OOMKilled
```spl
index=<k8s_index> namespace=<namespace> "OOMKilled"
| table _time namespace pod container message
```