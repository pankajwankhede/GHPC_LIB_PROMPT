# API Health Dashboard Skill

## Goal
Generate Splunk dashboard for API health, latency, traffic, errors, and SLA/SLO.

## Panels to Create
- Total Requests
- Success Count
- Error Count
- Error Rate %
- HTTP Status Code Distribution
- Average Latency
- P95 Latency
- P99 Latency
- Slowest Endpoints
- Top Failing Endpoints
- 4xx vs 5xx Trend
- Timeout Errors
- Downstream Dependency Failures
- Correlation ID Drilldown

## Example SPL

### Request Volume
```spl
index=<index> app=<app> env=<env>
| timechart span=5m count as totalRequests
```

### Error Rate
```spl
index=<index> app=<app> env=<env>
| eval isError=if(status>=500,1,0)
| timechart span=5m count as total, sum(isError) as errors
| eval errorRate=round((errors/total)*100,2)
```

### P95/P99 Latency
```spl
index=<index> app=<app> env=<env> durationMs=*
| timechart span=5m p95(durationMs) as p95, p99(durationMs) as p99 by endpoint
```