# JVM Dashboard Generator

## Goal
Create Splunk dashboards for Java/Spring Boot JVM monitoring.

## Monitor
- Heap usage
- Non-heap usage
- GC count
- GC pause time
- Thread count
- Deadlock indicators
- CPU usage
- OOM errors
- Memory leak patterns
- Slow request correlation
- Exception spikes

## Panels
- JVM Heap Trend
- GC Pause Trend
- Thread Count Trend
- OOM Error Count
- Top JVM Exceptions
- CPU Spike Timeline
- Memory Leak Suspicion
- Slow API vs Heap Correlation

## Example SPL

### OOM Errors
```spl
index=<index> app=<app> ("OutOfMemoryError" OR "GC overhead limit exceeded")
| stats count by host, pod, exception
```

### Thread Exhaustion
```spl
index=<index> app=<app> ("thread" AND ("exhausted" OR "rejected" OR "pool"))
| table _time host pod level message
```