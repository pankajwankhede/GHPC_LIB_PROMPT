# Business KPI Dashboard Generator

## Goal
Create dashboards for business transaction monitoring.

## Examples
- Orders created
- Payments completed
- Payments failed
- Login success
- User registration
- Claims submitted
- Checkout conversion
- Transaction failure
- Fraud rejects
- Batch processing success

## Panels
- Business Transaction Count
- Success vs Failure
- Business Error Codes
- Conversion Funnel
- SLA Breach Count
- Top Failure Reasons
- Revenue/Transaction Impact
- Region/Channel Breakdown

## Example SPL

### Transaction Success/Failure
```spl
index=<index> app=<app> eventType=BUSINESS_TRANSACTION
| timechart span=5m count by status
```