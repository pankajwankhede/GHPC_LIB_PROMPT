# Example Prompts

## Dashboard
Create Splunk dashboard for this Spring Boot API with request count, error rate, p95 latency, top exceptions, and slow endpoints.

## Query
Generate Splunk query to find all errors for correlationId abc-123.

## RCA
Generate RCA Splunk queries for incident between 10:00 and 10:30 AM.

## Auth
Create login failure and suspicious IP dashboard.

## Kubernetes
Create pod restart, OOMKilled, and CrashLoopBackOff dashboard.

## Alert
Create alert for API error rate above 5% for 10 minutes.