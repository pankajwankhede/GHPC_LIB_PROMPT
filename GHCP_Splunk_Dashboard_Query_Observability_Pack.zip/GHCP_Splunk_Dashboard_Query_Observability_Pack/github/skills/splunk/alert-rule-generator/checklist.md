# Splunk Observability Checklist

- [ ] Index identified
- [ ] Sourcetype identified
- [ ] App/service filter included
- [ ] Environment filter included
- [ ] Time range considered
- [ ] Correlation ID available
- [ ] Error rate query available
- [ ] Latency query available
- [ ] Dashboard panels defined
- [ ] Alerts defined
- [ ] Runbook action added
- [ ] PII masked