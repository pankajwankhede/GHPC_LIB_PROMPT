# Splunk Alert Rule Generator

## Goal
Generate Splunk alert rules with thresholds, severity, ownership, and runbook actions.

## Alert Types
- API error rate
- API latency
- Login failure spike
- JVM OOM
- Pod restart spike
- Kafka lag
- DB connection failure
- Downstream timeout
- Payment/transaction failure
- Deployment regression

## Output Standard
- Alert Name
- Purpose
- SPL Query
- Severity
- Threshold
- Trigger Condition
- Suppression Window
- Owner
- Runbook
- Escalation
- False Positive Notes

## Example Alert

### API 5xx Error Rate > 5%
```spl
index=<index> app=<app> env=prod
| eval is5xx=if(status>=500,1,0)
| stats count as total, sum(is5xx) as errors
| eval errorRate=(errors/total)*100
| where errorRate > 5
```