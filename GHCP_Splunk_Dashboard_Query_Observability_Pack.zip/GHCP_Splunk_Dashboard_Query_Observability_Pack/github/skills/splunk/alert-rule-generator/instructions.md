# Instructions

1. Identify monitoring goal.
2. Ask for or infer index, sourcetype, app, environment, and fields.
3. Generate SPL query.
4. Explain query purpose.
5. Provide dashboard panel layout.
6. Provide alert threshold when needed.
7. Add troubleshooting/runbook notes.
8. Avoid PII exposure.