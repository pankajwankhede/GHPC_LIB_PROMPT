# Splunk Field Extraction Advisor

## Goal
Improve logs so Splunk queries and dashboards become reliable.

## Recommended Standard Fields
- timestamp
- environment
- application
- service
- version
- traceId
- correlationId
- requestId
- endpoint
- method
- status
- durationMs
- level
- errorCode
- exception
- message
- pod
- host
- region

## Output Standard
- Current Logging Gaps
- Required Fields
- Field Extraction SPL
- Recommended JSON Log Format
- Dashboard Impact