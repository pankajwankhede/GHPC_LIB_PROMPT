# Auth/Security Dashboard Generator

## Goal
Create Splunk dashboards for login, logout, session, JWT, SAML/OIDC, CORS/CSRF, and suspicious activity monitoring.

## Panels
- Login Success vs Failure
- Top Failed Users/IPs
- JWT Validation Failure Trend
- SAML Failure Trend
- Session Error Trend
- CORS/CSRF Failure Trend
- Suspicious IPs
- Account Lockout Trend

## Example SPL

### Login Failure Rate
```spl
index=<index> app=<app> eventType=LOGIN
| eval failed=if(status="FAILURE",1,0)
| timechart span=5m count as total, sum(failed) as failures
| eval failureRate=round((failures/total)*100,2)
```

### Suspicious Login Attempts
```spl
index=<index> app=<app> eventType=LOGIN status=FAILURE
| stats count by userId, clientIp
| where count > 10
| sort -count
```

## Guardrails
- Never display raw JWT/SAML/session IDs.
- Mask user identifiers where required.
- Follow privacy rules.