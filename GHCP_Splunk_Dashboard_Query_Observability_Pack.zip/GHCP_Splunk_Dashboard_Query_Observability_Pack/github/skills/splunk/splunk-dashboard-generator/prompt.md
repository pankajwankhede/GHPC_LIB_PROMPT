# Splunk Dashboard Generator

## Goal
Create enterprise Splunk dashboard designs and panel queries.

## When to Use
Use when building dashboards for API monitoring, JVM monitoring, Kubernetes monitoring, login/auth monitoring, business transaction monitoring, release validation, production support, or SRE observability.

## Dashboard Types
- API Health Dashboard
- Service Health Dashboard
- JVM Dashboard
- Kubernetes Pod Dashboard
- Authentication Dashboard
- Business KPI Dashboard
- Release Monitoring Dashboard
- Incident RCA Dashboard
- Security Monitoring Dashboard

## Step-by-Step Workflow
1. Identify dashboard audience.
2. Identify service/application.
3. Define dashboard purpose.
4. Define global filters.
5. Define panels.
6. Create SPL for each panel.
7. Add thresholds.
8. Add drilldowns.
9. Add alert recommendations.
10. Provide dashboard layout.

## Standard Dashboard Filters
- Environment
- Application
- Service
- Endpoint
- Region
- Host/pod
- Time range
- Status code
- Correlation ID

## Standard Panels
1. Request Count
2. Error Count
3. Error Rate %
4. Average Latency
5. P95 Latency
6. P99 Latency
7. Top Failing APIs
8. Top Exceptions
9. Slowest Endpoints
10. Recent Deploy Impact
11. Auth Failures
12. JVM Memory
13. Pod Restarts
14. Kafka Lag
15. DB Failure Count

## Output Standard
- Dashboard Name
- Purpose
- Audience
- Global Filters
- Panel Layout
- Panel Queries
- Alerts Needed
- Drilldown Suggestions
- Operational Notes