# Splunk Query Generator

## Goal
Generate production-ready Splunk SPL queries for logs, APIs, errors, latency, authentication, JVM, Kubernetes, Kafka, and business events.

## When to Use
Use this skill when troubleshooting production issues, building dashboard searches, creating RCA query bundles, or creating alert searches.

## Prerequisites
- Splunk index name
- sourcetype
- application/service name
- environment
- correlationId/requestId field
- timestamp format
- log field names

## Step-by-Step Workflow
1. Identify service/application.
2. Identify index and sourcetype.
3. Identify log fields.
4. Identify monitoring goal.
5. Build base search.
6. Add filters.
7. Extract fields if needed.
8. Add stats/timechart.
9. Add thresholds.
10. Provide final SPL query.

## Output Standards
Provide:
- SPL query
- Explanation
- Dashboard usage
- Alert usage
- Performance notes
- PII/sensitive-data warning

## Example SPL

### Error Count
```spl
index=<index> sourcetype=<sourcetype> app=<app> env=<env> level=ERROR
| stats count by service, errorCode, exception
| sort -count
```

### API Latency
```spl
index=<index> app=<app> env=<env> endpoint=* durationMs=*
| timechart span=5m avg(durationMs) p95(durationMs) p99(durationMs) by endpoint
```

### Trace by Correlation ID
```spl
index=<index> correlationId="<correlation_id>"
| sort _time
| table _time service endpoint level message durationMs
```

## Guardrails
- Do not expose PII.
- Mask tokens/session IDs.
- Avoid expensive wildcard searches.
- Always filter by index, sourcetype, app, and environment.
- Prefer time-bounded searches.