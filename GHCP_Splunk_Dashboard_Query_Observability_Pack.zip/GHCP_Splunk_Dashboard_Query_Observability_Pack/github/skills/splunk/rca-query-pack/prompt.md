# Splunk RCA Query Pack

## Goal
Generate RCA investigation queries for production incidents.

## Step-by-Step RCA Workflow
1. Identify incident time window.
2. Compare before vs during incident.
3. Check error spike.
4. Check latency spike.
5. Check top exceptions.
6. Check downstream failures.
7. Check deployment/change events.
8. Check pod restarts/OOM.
9. Check traffic spike.
10. Trace sample correlation IDs.

## RCA Queries

### Error Trend
```spl
index=<index> app=<app> earliest=<start> latest=<end>
| timechart span=5m count by level
```

### Top Exceptions
```spl
index=<index> app=<app> level=ERROR
| stats count by exception, service, endpoint
| sort -count
```

### Slow Endpoints
```spl
index=<index> app=<app> durationMs=*
| stats avg(durationMs) p95(durationMs) p99(durationMs) count by endpoint
| sort -p99
```