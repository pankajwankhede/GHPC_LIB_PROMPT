# Confluence App Documentation Generator

## Goal
Generate complete Confluence-ready application documentation.

## When to Use
Use when documenting:
- New application
- Existing application
- Microservice
- API platform
- Migration project
- Production support handover
- Integration project

## What to Create
- Application overview
- Business purpose
- High-level architecture
- Integration guide
- API documentation
- Data flow
- Sequence diagrams
- Class diagrams
- Deployment diagram
- Security flow
- Monitoring guide
- Runbook
- Troubleshooting
- FAQ

## Confluence Page Structure
1. Executive Summary
2. Business Context
3. Application Overview
4. Architecture Overview
5. Integration Guide
6. API Contracts
7. Data Model
8. Security Model
9. Deployment Model
10. Observability
11. Operations Runbook
12. Troubleshooting
13. Diagrams
14. References

## Output Standard
Generate content in Confluence-friendly Markdown with:
- Headings
- Tables
- Code blocks
- Mermaid diagrams
- PlantUML diagrams
- Draw.io guidance
- Page tree structure