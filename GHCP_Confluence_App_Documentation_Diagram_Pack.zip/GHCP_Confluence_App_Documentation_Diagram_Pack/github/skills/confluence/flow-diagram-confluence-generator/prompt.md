# Flow Diagram Generator for Confluence

## Goal
Generate Confluence-ready flow diagrams.

## Flow Types
- Application flow
- Business process flow
- Controller flow
- Endpoint flow
- Error flow
- Login/logout flow
- Batch flow
- Approval flow
- Deployment flow

## Output
- Mermaid flowchart
- PlantUML activity diagram
- Step table
- Exception path
- Notes

## Required Sections
- Flow summary
- Happy path
- Alternate path
- Error path
- Retry path
- Validation rules