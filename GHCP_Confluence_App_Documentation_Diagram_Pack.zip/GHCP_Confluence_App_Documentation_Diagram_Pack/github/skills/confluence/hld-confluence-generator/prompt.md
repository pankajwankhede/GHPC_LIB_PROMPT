# HLD Confluence Generator

## Goal
Create a High-Level Design document for Confluence.

## Sections
- Purpose
- Scope
- Business problem
- Current state
- Target state
- Architecture overview
- System context
- Component overview
- Integration points
- Security architecture
- Data flow
- Deployment architecture
- NFRs
- Risks
- Assumptions
- Open questions
- Decision log

## Diagrams
- System context diagram
- Container diagram
- Component diagram
- Integration diagram
- Deployment diagram
- Data flow diagram

## Output Format
Provide:
- Confluence page content
- Mermaid diagram blocks
- PlantUML blocks
- Architecture decision table
- Risk table