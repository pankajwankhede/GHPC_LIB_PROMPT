# ERD Confluence Generator

## Goal
Generate Entity Relationship Diagrams for Confluence.

## Input
- JPA entities
- SQL DDL
- Database schema
- Repository layer
- Requirement

## Output
- Mermaid ERD
- Table dictionary
- Relationship explanation
- PK/FK details
- Index recommendations
- Data integrity notes

## Mermaid Example
```mermaid
erDiagram
    USER ||--o{ ORDER : places
    ORDER ||--|{ ORDER_ITEM : contains
```