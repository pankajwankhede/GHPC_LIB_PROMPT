# Integration Guide Generator

## Goal
Generate complete integration guide for Confluence.

## Include
- Integration overview
- Consumer/provider details
- Authentication
- Authorization
- Network requirements
- API endpoints
- Request/response examples
- Error codes
- Retry policy
- Timeout policy
- Idempotency
- Rate limits
- Headers
- Payload schema
- Security requirements
- Monitoring
- Testing approach
- Contact/support model

## Diagrams
- Integration context diagram
- Sequence diagram
- API flow diagram
- Error flow diagram
- Auth flow diagram

## Output Standard
Confluence-ready guide with tables and code blocks.