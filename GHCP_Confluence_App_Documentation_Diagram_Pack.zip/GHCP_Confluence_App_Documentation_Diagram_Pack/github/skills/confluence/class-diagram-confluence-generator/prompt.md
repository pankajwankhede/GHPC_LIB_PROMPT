# Class Diagram Generator for Confluence

## Goal
Generate class diagrams for Java/Spring Boot code.

## Analyze
- Controllers
- Services
- Repositories
- DTOs
- Entities
- Mappers
- Interfaces
- Inheritance
- Composition
- Dependencies

## Output
- Mermaid class diagram
- PlantUML class diagram
- Class responsibility table
- Relationship explanation
- Design concerns

## Mermaid Example
```mermaid
classDiagram
    class UserController
    class UserService
    class UserRepository
    UserController --> UserService
    UserService --> UserRepository
```