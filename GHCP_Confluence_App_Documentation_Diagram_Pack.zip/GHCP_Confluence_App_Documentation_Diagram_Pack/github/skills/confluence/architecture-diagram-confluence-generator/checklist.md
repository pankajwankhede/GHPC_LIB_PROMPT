# Confluence Documentation Checklist

- [ ] Application overview added
- [ ] Business context added
- [ ] HLD added
- [ ] Integration guide added
- [ ] API contracts added
- [ ] Flow diagrams added
- [ ] Sequence diagrams added
- [ ] Class diagrams added
- [ ] ERD added
- [ ] Deployment diagram added
- [ ] Security/auth flow added
- [ ] Monitoring/runbook added
- [ ] Troubleshooting added
- [ ] Risks/open questions added