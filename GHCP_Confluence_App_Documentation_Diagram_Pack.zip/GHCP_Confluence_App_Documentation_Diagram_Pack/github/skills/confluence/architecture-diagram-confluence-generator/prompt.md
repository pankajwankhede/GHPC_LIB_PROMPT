# Architecture Diagram Generator for Confluence

## Goal
Generate architecture diagrams supported by Confluence-compatible formats.

## Supported Diagram Types
- Mermaid architecture diagram
- PlantUML component diagram
- C4 context/container/component diagrams
- Draw.io diagram instructions
- Deployment diagram
- Network/trust boundary diagram

## Output
- Mermaid code
- PlantUML code
- Draw.io layout instructions
- Explanation
- Component table

## Mermaid Example
```mermaid
flowchart LR
    User[User] --> Akamai[Akamai/CDN]
    Akamai --> Nginx[NGINX/API Gateway]
    Nginx --> App[Spring Boot App]
    App --> DB[(Database)]
    App --> Splunk[Splunk]
```