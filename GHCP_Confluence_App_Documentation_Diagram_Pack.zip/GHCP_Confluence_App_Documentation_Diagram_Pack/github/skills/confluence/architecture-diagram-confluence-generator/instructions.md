# Instructions

1. Identify the application or feature to document.
2. Extract architecture, APIs, integrations, data model, security, deployment, and operations details.
3. Generate Confluence-ready page content.
4. Include diagrams in Mermaid and/or PlantUML.
5. Include assumptions and missing information.
6. Include risks, open questions, and references.
7. Keep content structured for copy-paste into Confluence.