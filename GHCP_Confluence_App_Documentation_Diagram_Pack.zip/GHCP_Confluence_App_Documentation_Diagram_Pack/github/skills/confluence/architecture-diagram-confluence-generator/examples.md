# Example Prompts

## Complete App Documentation
Create Confluence documentation for this application including HLD, integration guide, flow diagram, class diagram, sequence diagram, ERD, deployment diagram, monitoring, and runbook.

## Controller Documentation
Create Confluence page for this Spring Boot controller with endpoint flow, sequence diagram, request/response, error handling, and class diagram.

## Integration Guide
Create integration guide for this API including auth, headers, request/response, error codes, retry policy, timeout, idempotency, and sequence diagram.

## Architecture Diagrams
Generate Mermaid and PlantUML diagrams for application architecture, deployment, class structure, and data flow.