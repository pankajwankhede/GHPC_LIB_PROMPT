# Confluence Page Tree Generator

## Goal
Generate recommended Confluence page hierarchy for an app.

## Page Tree
- Home
  - Application Overview
  - Architecture
    - HLD
    - LLD
    - System Context
    - Component Diagram
    - Deployment Diagram
  - Integrations
    - API Integration Guide
    - External Systems
    - Auth Flow
  - Data
    - Data Model
    - ERD
    - Data Retention
  - Operations
    - Monitoring
    - Alerts
    - Runbook
    - Troubleshooting
  - Release
    - Deployment Guide
    - Rollback Plan
    - Release Notes
  - Security
    - Security Model
    - Threat Model
    - Compliance