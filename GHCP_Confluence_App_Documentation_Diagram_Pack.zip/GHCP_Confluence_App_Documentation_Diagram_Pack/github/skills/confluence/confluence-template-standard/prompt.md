# Confluence Template Standard

## Goal
Standardize all Confluence pages.

## Required Page Elements
- Title
- Owner
- Last updated
- Status
- Purpose
- Scope
- Assumptions
- Content
- Diagrams
- Tables
- Risks
- Open Questions
- References

## Formatting Rules
- Use H1/H2/H3 headings
- Use tables for structured data
- Use code blocks for Mermaid/PlantUML
- Use info/warning/note callouts where supported
- Keep diagrams close to explanations