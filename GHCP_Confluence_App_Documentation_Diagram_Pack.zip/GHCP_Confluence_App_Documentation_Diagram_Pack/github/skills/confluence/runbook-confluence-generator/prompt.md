# Runbook Confluence Generator

## Goal
Generate production support runbook for Confluence.

## Include
- Service overview
- Health checks
- Dashboards
- Alerts
- Splunk queries
- Common failures
- Recovery steps
- Rollback steps
- Escalation path
- Contact matrix
- Validation steps

## Output
Confluence-ready operational runbook.