# Sequence Diagram Generator for Confluence

## Goal
Generate sequence diagrams for application/API flows.

## Use For
- API endpoint flow
- Login/auth flow
- SAML/OIDC flow
- Payment flow
- Kafka/event flow
- External integration flow
- Batch process flow

## Output
- Mermaid sequence diagram
- PlantUML sequence diagram
- Step explanation
- Failure scenarios
- Timeout/retry handling

## Mermaid Example
```mermaid
sequenceDiagram
    actor User
    participant UI
    participant API
    participant Service
    participant DB
    User->>UI: Submit request
    UI->>API: POST /api/resource
    API->>Service: process()
    Service->>DB: save()
    DB-->>Service: success
    Service-->>API: response
    API-->>UI: 200 OK
```