# Deployment Diagram Generator for Confluence

## Goal
Generate deployment architecture documentation.

## Include
- User/browser
- CDN/Akamai
- Load balancer
- NGINX/API gateway
- Kubernetes/PCF
- Spring Boot app
- Database
- Redis/cache
- Kafka/queue
- Secrets/config
- Splunk/monitoring
- External systems

## Output
- Mermaid deployment diagram
- PlantUML deployment diagram
- Environment table
- Infra component table
- Network/security boundary notes