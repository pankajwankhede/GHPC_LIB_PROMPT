# Confluence Diagram Cheatsheet

## Mermaid
Use Mermaid code blocks where Confluence supports Mermaid through plugin or markdown rendering.

## PlantUML
Use PlantUML macro/plugin where available.

## Draw.io
Use diagrams.net/draw.io macro for editable enterprise diagrams.

## Recommended Diagram Types
- Architecture: Mermaid flowchart or C4
- Sequence: Mermaid sequenceDiagram or PlantUML
- Class: Mermaid classDiagram or PlantUML
- ERD: Mermaid erDiagram
- Deployment: Mermaid flowchart or PlantUML deployment
- Use Case: PlantUML usecase