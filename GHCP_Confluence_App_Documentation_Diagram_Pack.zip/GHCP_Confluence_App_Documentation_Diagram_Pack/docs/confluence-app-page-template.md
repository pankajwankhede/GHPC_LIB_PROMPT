# Application Documentation Template

## Page Title
<Application Name> - Application Documentation

## Owner
Team:

## Status
Draft / Reviewed / Approved

## Executive Summary

## Business Context

## Application Overview

## Architecture Overview

```mermaid
flowchart LR
    User[User] --> UI[Frontend]
    UI --> API[Backend API]
    API --> DB[(Database)]
    API --> EXT[External System]
```

## Integration Guide

## API Contracts

## Data Model

## Security Model

## Deployment Model

## Monitoring and Alerts

## Runbook

## Troubleshooting

## Risks and Open Questions

## References