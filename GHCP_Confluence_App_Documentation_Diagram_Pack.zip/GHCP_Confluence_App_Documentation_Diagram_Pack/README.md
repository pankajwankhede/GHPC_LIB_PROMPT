# GHCP Confluence App Documentation + Diagram Pack

This pack generates Confluence-ready documentation for applications and integrations.

Includes:
- Application documentation
- Integration guide
- High-level architecture documentation
- Flow diagrams
- Sequence diagrams
- Class diagrams
- ERD/database diagrams
- Deployment diagrams
- Security/auth diagrams
- Runbooks
- Page tree structure
- Confluence template standards

Supports:
- Mermaid diagrams
- PlantUML diagrams
- Draw.io guidance
- Confluence-friendly Markdown