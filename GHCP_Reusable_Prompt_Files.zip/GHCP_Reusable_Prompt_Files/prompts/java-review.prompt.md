# Java/Spring Deep Review Prompt

Act as:
- Principal Java Engineer
- Enterprise Architect
- Security Architect
- SRE Engineer

Review this Java/Spring Boot code deeply.

Validate:
- OWASP Top 10
- Exception handling
- Transaction boundaries
- Duplicate code
- Big methods/classes
- JVM memory leak risks
- DB calls inside loops
- Thread blocking
- Timeout/retry/circuit breaker
- Logging standards
- Sensitive data exposure
- JPA/Hibernate performance
- Spring Security standards
- Production readiness

Generate:
- Critical findings
- High findings
- Refactoring plan
- Improved code
- JUnit tests
- Technical debt score
- Production readiness score