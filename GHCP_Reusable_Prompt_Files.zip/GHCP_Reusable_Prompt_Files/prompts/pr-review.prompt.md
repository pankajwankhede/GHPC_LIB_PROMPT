# Pull Request Review Prompt

Review this PR like a principal engineer.

Detect:
- Security risks
- Performance risks
- Duplicate code
- Big methods/classes
- Thread safety issues
- Memory leaks
- Transaction issues
- API contract breaking changes
- Poor exception handling

Provide:
- Severity
- Risk
- Fix
- Refactored code
- Approval decision