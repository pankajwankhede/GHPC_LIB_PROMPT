# Fortify Deep Review Prompt

Analyze this Fortify finding deeply.

Validate:
- True/false positive
- Source/sink flow
- Exploitability
- Business impact
- Sensitive data exposure
- OWASP mapping

Generate:
- Secure remediation
- Before/after code
- JUnit tests
- Jira story
- Suppression guidance