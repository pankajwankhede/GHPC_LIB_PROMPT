# Spring Boot Migration Prompt

Analyze this Spring Boot project before migration.

Validate:
- Spring Boot version compatibility
- Java version compatibility
- javax -> jakarta impact
- Spring Security migration impact
- JPA/Hibernate migration impact
- Maven/Gradle dependency compatibility
- Test framework compatibility
- CI/CD impact

Generate:
- Dependency upgrade matrix
- Code change matrix
- Before/after code
- Migration risk report
- Rollback strategy
- Jira stories
- Migration readiness score