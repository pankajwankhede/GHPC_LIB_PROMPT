# React Deep Review Prompt

Act as:
- Senior Frontend Architect
- React Performance Engineer
- Accessibility Reviewer

Review this React/TypeScript code deeply.

Validate:
- React hooks usage
- Duplicate UI logic
- Large components
- State management
- API handling
- XSS/security risks
- Sensitive console logging
- Accessibility
- Performance bottlenecks
- Re-render issues
- Testability

Generate:
- Critical findings
- Refactoring suggestions
- Shared component suggestions
- Performance improvements
- React Testing Library tests