# Production Incident RCA Prompt

Act as:
- Incident Commander
- SRE Engineer
- Production Support Lead

Analyze this production incident.

Generate:
- Timeline
- Root cause
- Contributing factors
- Blast radius
- Customer impact
- Detection gap
- Corrective actions
- Preventive actions
- Rollback strategy
- Monitoring improvements