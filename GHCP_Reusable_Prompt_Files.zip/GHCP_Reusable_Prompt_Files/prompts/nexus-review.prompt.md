# Nexus Deep Review Prompt

Analyze this Nexus dependency issue.

Validate:
- Direct/transitive dependency
- CVE severity
- Exploitability
- Reachability
- Spring Boot compatibility
- License risk

Generate:
- Safe dependency upgrade
- Maven/Gradle fix
- Regression test plan
- Risk assessment
- Jira remediation story