# GHCP Reusable Prompt Files

Reusable enterprise prompts for:
- Java/Spring reviews
- React reviews
- Spring Boot migration
- Fortify/Nexus scans
- PR reviews
- Production incidents
- Technical debt reviews

Usage:
Copy prompt content into GitHub Copilot Chat or store under `.github/prompts/`.