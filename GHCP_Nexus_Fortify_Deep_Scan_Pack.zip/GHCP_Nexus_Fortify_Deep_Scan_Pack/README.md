
# GHCP Nexus + Fortify Deep Scan Pack

This project contains deep enterprise prompts for:
- Fortify SAST review
- Nexus IQ / SCA dependency review
- CI/CD security quality gates
- Jira remediation story generation
