
# Enterprise Security Scan Policy

## Fortify
Critical and High findings in new code must be fixed before production deployment.

## Nexus
Critical exploitable CVEs with available fixes must fail the build.

## Suppression
Every suppression requires:
- Owner
- Expiry date
- Business justification
- Security approval
- Evidence
