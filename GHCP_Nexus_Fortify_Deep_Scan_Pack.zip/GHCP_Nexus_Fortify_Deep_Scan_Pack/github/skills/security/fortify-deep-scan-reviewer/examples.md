
# Fortify Example Prompts

## Prompt 1
Review this Fortify SQL Injection finding and provide secure Spring Boot remediation with JUnit tests.

## Prompt 2
Fortify reported Log Forging in this Java method. Verify if it is true positive and fix it.

## Prompt 3
Analyze this Fortify Privacy Violation issue. Check if sensitive data is logged or returned in API response.

## Prompt 4
Fortify reported Path Manipulation. Validate source-to-sink flow and provide allowlist validation.

## Prompt 5
Review all Fortify findings in this report and create remediation backlog by severity.
