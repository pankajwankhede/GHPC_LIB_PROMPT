
# Instructions

1. Identify tool: Fortify or Nexus.
2. Identify severity and component.
3. Validate whether issue is exploitable.
4. Provide exact remediation.
5. Provide code or dependency fix.
6. Add validation steps.
7. Add Jira-ready action items.
8. Recommend whether build should pass, warn, or fail.
