
# Fortify Deep Scan Checklist

## Finding Triage
- [ ] Finding category identified
- [ ] Severity validated
- [ ] Source identified
- [ ] Sink identified
- [ ] Data flow reviewed
- [ ] Trust boundary reviewed
- [ ] True/false positive decided

## Java/Spring Boot Fix
- [ ] Input validation added
- [ ] Output encoding added
- [ ] Parameterized query used
- [ ] Sensitive logging removed
- [ ] Exception handling secured
- [ ] Authorization verified
- [ ] Unit test added
- [ ] Security regression test added

## Documentation
- [ ] Risk documented
- [ ] Fix documented
- [ ] False positive justification documented if applicable
- [ ] Developer action item created
