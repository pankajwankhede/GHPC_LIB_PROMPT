
# Deep Security Scan Skill

Enterprise-grade prompt skill for Fortify SAST and Nexus SCA review.

## Purpose
This skill helps teams:
- Triage findings
- Validate true/false positives
- Fix vulnerable code
- Upgrade vulnerable dependencies
- Create CI/CD quality gates
- Generate Jira remediation stories
- Prepare audit evidence

## Usage
Paste Fortify/Nexus finding, code, pom.xml, or scan report and ask the AI to review using this skill.
