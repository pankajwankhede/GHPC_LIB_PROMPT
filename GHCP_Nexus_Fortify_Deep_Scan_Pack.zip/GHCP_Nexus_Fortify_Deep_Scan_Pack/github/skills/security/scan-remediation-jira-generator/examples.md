
# Jira Generator Prompts

## Prompt 1
Convert these Fortify findings into Jira stories.

## Prompt 2
Convert Nexus critical CVEs into remediation backlog.

## Prompt 3
Create sprint-ready security stories with acceptance criteria.
