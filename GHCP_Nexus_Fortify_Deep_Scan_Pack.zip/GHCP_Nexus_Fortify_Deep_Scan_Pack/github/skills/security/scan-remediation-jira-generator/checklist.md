
# Scan Jira Checklist

- [ ] Severity mapped
- [ ] Component identified
- [ ] Fix clearly described
- [ ] Acceptance criteria added
- [ ] Evidence required
- [ ] Owner assigned
- [ ] Due date based on SLA
