
# CI/CD Quality Gate Example Prompts

## Prompt 1
Create Jenkins pipeline quality gate for Fortify and Nexus.

## Prompt 2
Define fail/warn/allow rules for enterprise security scans.

## Prompt 3
Create exception process for false positives and risk acceptance.

## Prompt 4
Generate GitHub Actions workflow for Maven build with Nexus and Fortify checks.
