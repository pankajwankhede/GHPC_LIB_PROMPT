
# DevSecOps Quality Gate Checklist

- [ ] Fortify scan configured
- [ ] Nexus scan configured
- [ ] Critical issues fail build
- [ ] High issues require approval
- [ ] Suppression process documented
- [ ] Risk acceptance owner assigned
- [ ] Jira ticket created
- [ ] Re-scan required after fix
