
# Nexus Deep Scan Checklist

## Dependency Analysis
- [ ] Direct/transitive dependency identified
- [ ] Parent dependency identified
- [ ] CVE reviewed
- [ ] CVSS reviewed
- [ ] Fixed version identified
- [ ] License issue reviewed
- [ ] Policy violation reviewed

## Remediation
- [ ] BOM compatibility checked
- [ ] Safe upgrade path selected
- [ ] Exclusion needed or not
- [ ] Regression test scope defined
- [ ] Nexus rescan required

## Enterprise Decision
- [ ] Fix now
- [ ] Risk accept
- [ ] Suppression justification
- [ ] Jira remediation story created
