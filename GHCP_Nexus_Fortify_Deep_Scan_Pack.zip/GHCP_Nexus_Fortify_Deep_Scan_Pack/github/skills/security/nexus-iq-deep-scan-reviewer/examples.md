
# Nexus Example Prompts

## Prompt 1
Review this Nexus IQ finding and suggest safe Maven dependency upgrade.

## Prompt 2
This vulnerable dependency is transitive. Find the parent dependency and provide exclusion + override fix.

## Prompt 3
Review this pom.xml for vulnerable dependencies and recommend safe Spring Boot compatible versions.

## Prompt 4
Create Jira stories for these Nexus critical and high findings.

## Prompt 5
Generate CI/CD quality gate rules for Nexus scan failure.
