# GHCP Agent Prompt Pack

Reusable enterprise AI agent prompts for:
- Java review
- React review
- Migration
- Fortify/Nexus
- Technical debt
- SRE
- Kubernetes
- Security
- Performance
- Production support
- Architecture/diagram generation

Usage:
Copy prompts into GitHub Copilot Chat or store under `.github/prompts/`.