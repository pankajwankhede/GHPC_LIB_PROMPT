# React Code Review Example Prompts

## Full Review
Review this React component deeply for code quality, security, accessibility, performance, and testability.

## PR Review
Review this React PR diff and decide APPROVE or REQUEST CHANGES.

## Security Review
Check this frontend code for XSS, unsafe token storage, sensitive logs, and unsafe redirects.

## Performance Review
Analyze this React component for unnecessary re-renders and API performance problems.

## Standards Review
Check this React code against enterprise coding standards and provide refactored code.