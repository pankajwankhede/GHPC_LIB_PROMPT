# React Enterprise Coding Standards

## Component Standards
- Use functional components.
- Keep components small and focused.
- Separate UI, business logic, and API calls.
- Prefer composition over large conditional JSX blocks.
- Extract reusable components.

## Hook Standards
- Do not call hooks conditionally.
- Keep dependency arrays accurate.
- Move complex hook logic into custom hooks.
- Clean up effects on unmount.
- Use AbortController for cancellable requests.

## TypeScript Standards
- Avoid `any`.
- Define prop interfaces.
- Type API request/response models.
- Use discriminated unions for complex UI states.
- Avoid broad type assertions.

## Security Standards
- Do not store secrets in frontend code.
- Avoid localStorage for sensitive auth tokens unless approved.
- Never log tokens, session IDs, PII, or financial data.
- Avoid `dangerouslySetInnerHTML`.
- Validate and encode user-controlled output.
- Use allowlist for redirects.

## Performance Standards
- Avoid expensive work during render.
- Use lazy loading for large routes/features.
- Virtualize large lists.
- Debounce search inputs.
- Avoid unnecessary state duplication.
- Memoize only with measurable benefit.

## Accessibility Standards
- Use semantic elements.
- Every input must have a label.
- Buttons must be buttons, links must be links.
- Ensure keyboard access.
- Manage focus for modals/dialogs.
- Provide accessible error messages.

## Testing Standards
- Test user behavior, not implementation details.
- Use React Testing Library.
- Mock API at boundary.
- Cover loading, error, empty, success states.
- Add accessibility-focused tests.