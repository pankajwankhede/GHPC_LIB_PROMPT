# React Deep Code Review Checklist

## Correctness
- [ ] Requirement implemented correctly
- [ ] Loading state handled
- [ ] Error state handled
- [ ] Empty state handled
- [ ] Null/undefined handled
- [ ] Async race condition avoided

## React Standards
- [ ] Hooks used correctly
- [ ] Dependency arrays correct
- [ ] Component responsibility clear
- [ ] Reusable components extracted
- [ ] No unnecessary re-renders
- [ ] No business logic mixed deeply in JSX

## TypeScript
- [ ] No unnecessary any
- [ ] Props typed
- [ ] API responses typed
- [ ] Clean imports
- [ ] Constants extracted

## Security
- [ ] No secrets in frontend
- [ ] No sensitive console logs
- [ ] No unsafe HTML injection
- [ ] User input sanitized/validated
- [ ] Redirect URLs safe
- [ ] Token handling reviewed

## Accessibility
- [ ] Semantic HTML
- [ ] Labels present
- [ ] Keyboard navigation works
- [ ] Focus handled
- [ ] ARIA not misused
- [ ] Errors announced accessibly

## Performance
- [ ] Large lists optimized
- [ ] Unnecessary renders avoided
- [ ] API calls not duplicated
- [ ] Debounce/throttle where needed
- [ ] Lazy loading considered

## Testing
- [ ] Component tests added
- [ ] Error state tested
- [ ] Accessibility tested
- [ ] API mock tests added