# Deep Code Review & Coding Standards Skill

Enterprise-grade prompt skill for GitHub Copilot / AI reviewer agents.

## Purpose
Use this skill to review code deeply for:
- Code quality
- Security
- Maintainability
- Performance
- Accessibility
- Testability
- Architecture standards
- Production readiness

## Usage
Paste code, PR diff, file, component, service, API, or project structure and ask the AI to review using this skill.