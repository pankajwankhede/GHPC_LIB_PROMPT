# Java/Spring Boot Enterprise Coding Standards

## Project Standards
- Use clear package structure: controller, service, repository, dto, mapper, config, exception.
- Keep business logic out of controllers.
- Do not expose JPA entities directly in API responses.
- Use constructor injection.
- Avoid field injection.
- Keep methods small and focused.

## API Standards
- Use proper HTTP methods.
- Use meaningful status codes.
- Validate request DTOs with Bean Validation.
- Use standard error response model.
- Add pagination for list APIs.
- Add idempotency for retryable write operations.

## Security Standards
- Enforce authentication and authorization.
- Validate all external input.
- Use parameterized queries.
- Do not log PII, JWTs, session IDs, tokens, passwords, SAML assertions, account/card data.
- Externalize secrets.
- Use secure cookies.
- Review CORS and CSRF configuration.
- Hide internal exceptions from API clients.

## Exception Standards
- Use @ControllerAdvice.
- Use custom business exceptions.
- Do not return stack traces.
- Log technical details internally only.
- Return safe business error messages.

## Logging Standards
- Use structured logs.
- Include correlation ID.
- Use proper log levels.
- Mask sensitive data.
- Avoid log forging by sanitizing user-controlled values.

## Database Standards
- Use indexes for high-volume queries.
- Avoid N+1 queries.
- Use pagination.
- Keep transactions short.
- Avoid unnecessary eager fetching.
- Use optimistic locking where needed.

## Resiliency Standards
- Add timeouts for external calls.
- Use retry with exponential backoff only for retryable failures.
- Use circuit breakers.
- Ensure idempotency for retryable operations.
- Add DLQ for async message failures.

## Testing Standards
- Use JUnit 5.
- Use Mockito for unit tests.
- Use MockMvc for controller tests.
- Use Testcontainers where DB behavior matters.
- Cover positive, negative, exception, and edge cases.