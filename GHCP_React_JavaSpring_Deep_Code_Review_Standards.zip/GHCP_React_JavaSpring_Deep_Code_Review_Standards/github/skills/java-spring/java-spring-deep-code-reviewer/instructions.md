# Instructions

1. Understand the business purpose of the code.
2. Identify the layer/component being reviewed.
3. Review correctness first.
4. Review security and data exposure.
5. Review performance and scalability.
6. Review maintainability and readability.
7. Review testability.
8. Review production readiness.
9. Provide actionable fixes with code examples.
10. Score the code and give final approval/rework decision.