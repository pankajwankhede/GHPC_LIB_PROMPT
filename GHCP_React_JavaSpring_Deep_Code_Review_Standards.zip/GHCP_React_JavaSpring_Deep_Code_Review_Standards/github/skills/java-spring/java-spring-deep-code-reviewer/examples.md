# Java/Spring Boot Code Review Example Prompts

## Full Review
Review this Spring Boot code deeply for enterprise standards, security, performance, and production readiness.

## PR Review
Review this Java PR diff and decide APPROVE or REQUEST CHANGES.

## Security Review
Check this controller/service for auth bypass, sensitive logs, validation gaps, SQL injection, and unsafe exception handling.

## Performance Review
Review this repository/service for N+1 queries, slow DB calls, missing pagination, and external API timeout issues.

## Standards Review
Check this Java code against enterprise coding standards and provide refactored code.