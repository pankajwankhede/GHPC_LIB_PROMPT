# Java/Spring Boot Deep Code Review Checklist

## Correctness
- [ ] Business rules implemented
- [ ] Edge cases handled
- [ ] Null handling correct
- [ ] Error paths handled
- [ ] Transaction behavior correct

## Layering
- [ ] Controller clean
- [ ] Service owns business logic
- [ ] Repository owns persistence
- [ ] DTO/entity separation
- [ ] Constructor injection used
- [ ] No circular dependency

## API
- [ ] HTTP methods correct
- [ ] Status codes correct
- [ ] Request validation added
- [ ] Response model clean
- [ ] Error response standardized
- [ ] Pagination added where needed

## Security
- [ ] Authentication checked
- [ ] Authorization checked
- [ ] Object-level access control checked
- [ ] Input validation checked
- [ ] SQL injection avoided
- [ ] Sensitive logs removed
- [ ] Secrets externalized
- [ ] CORS/CSRF reviewed
- [ ] JWT/SAML/OIDC reviewed

## Logging/Observability
- [ ] Correlation ID
- [ ] Structured logs
- [ ] Proper log levels
- [ ] Metrics considered
- [ ] Tracing considered

## Performance/Resiliency
- [ ] DB queries optimized
- [ ] N+1 checked
- [ ] Timeout configured
- [ ] Retry with backoff
- [ ] Circuit breaker
- [ ] Idempotency

## Testing
- [ ] Unit tests
- [ ] MockMvc tests
- [ ] Integration tests
- [ ] Security tests
- [ ] Exception tests