# PR Review Output Template

## Decision
APPROVE / APPROVE WITH COMMENTS / REQUEST CHANGES

## Summary
Short summary.

## Blocking Issues
Critical/high issues.

## Non-Blocking Suggestions
Medium/low improvements.

## Security Review
Sensitive data, auth, validation, OWASP.

## Performance Review
Latency, rendering, DB, memory, external calls.

## Testing Review
Missing tests and recommended test cases.

## Score
1 to 10.