# Severity Model

## Critical
Production outage, exploitable vulnerability, data leak, auth bypass.

## High
Major security/performance issue, broken business flow, unsafe production behavior.

## Medium
Maintainability, testability, moderate performance risk.

## Low
Style, naming, minor cleanup.