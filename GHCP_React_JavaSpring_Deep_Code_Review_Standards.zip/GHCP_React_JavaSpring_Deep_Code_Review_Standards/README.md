# GHCP React + Java/Spring Deep Code Review Standards Pack

This project contains enterprise-grade prompts and standards for:
- React / JavaScript / TypeScript frontend code review
- Java / Spring Boot backend code review
- Security standards
- Performance standards
- Accessibility standards
- Testing standards
- PR review decision framework