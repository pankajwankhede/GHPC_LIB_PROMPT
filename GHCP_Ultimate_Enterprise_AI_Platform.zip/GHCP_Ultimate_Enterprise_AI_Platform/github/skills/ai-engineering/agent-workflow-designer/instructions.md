
# Instructions

1. Understand the business problem
2. Review technical design
3. Review architecture
4. Review security posture
5. Review scalability
6. Review production readiness
7. Review observability
8. Generate actionable improvements

# Must Check
- Authentication
- Authorization
- Logging
- Validation
- Retry/Timeout/Circuit Breaker
- DB optimization
- Kubernetes readiness
- CI/CD quality gates
