
# Checklist

## Security
- [ ] OWASP reviewed
- [ ] Secrets removed
- [ ] PII masked

## Architecture
- [ ] Scalable
- [ ] Resilient
- [ ] Maintainable

## Production
- [ ] Monitoring configured
- [ ] Alerts configured
- [ ] Rollback strategy ready

## Quality
- [ ] Unit tests available
- [ ] Integration tests available
- [ ] Performance reviewed
