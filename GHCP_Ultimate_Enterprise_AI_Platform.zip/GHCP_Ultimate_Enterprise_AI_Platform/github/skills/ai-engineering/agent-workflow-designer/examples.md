
# Example Prompts

- Review this Spring Boot service for security and scalability.
- Generate enterprise-grade JUnit test cases.
- Review Kubernetes deployment YAML.
- Analyze production outage root cause.
- Generate HLD and LLD for this requirement.
