# GHCP_Solution_Architecture_Pack

Enterprise GHCP pack skeleton.
