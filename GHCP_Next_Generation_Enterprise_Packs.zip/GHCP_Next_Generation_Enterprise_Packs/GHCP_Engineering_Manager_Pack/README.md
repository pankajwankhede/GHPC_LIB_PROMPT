# GHCP_Engineering_Manager_Pack

Enterprise GHCP pack skeleton.
