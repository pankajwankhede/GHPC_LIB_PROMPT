# GHCP_Kubernetes_Platform_Pack

Enterprise GHCP pack skeleton.
