# GHCP_FinOps_Cost_Optimization_Pack

Enterprise GHCP pack skeleton.
