# GHCP_Technical_Debt_Factory

Enterprise GHCP pack skeleton.
