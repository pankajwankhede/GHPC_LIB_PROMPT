# GHCP_Security_Architecture_Pack

Enterprise GHCP pack skeleton.
