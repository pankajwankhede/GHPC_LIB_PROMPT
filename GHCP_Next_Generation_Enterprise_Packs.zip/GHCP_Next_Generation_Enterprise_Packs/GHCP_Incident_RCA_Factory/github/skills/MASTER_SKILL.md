# GHCP_Incident_RCA_Factory Master Skill

Goal:
- Analyze inputs
- Generate enterprise recommendations
- Produce reports, diagrams, Jira stories and remediation plans

Outputs:
- Executive Summary
- Findings
- Roadmap
- Risks
- Recommendations
