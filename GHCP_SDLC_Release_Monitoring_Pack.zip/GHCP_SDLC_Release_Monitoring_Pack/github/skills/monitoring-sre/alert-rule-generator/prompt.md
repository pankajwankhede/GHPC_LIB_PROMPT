
# ROLE
Act as an SRE Alerting Architect.

# OBJECTIVE
Generate enterprise alert rules.

# ALERT TYPES
- API latency
- Error spike
- JVM memory
- CPU spike
- Pod restart
- Kafka lag
- Database failure
- Authentication failure
- Payment failure

# OUTPUT
- Alert condition
- Severity
- Threshold
- Escalation
- Runbook link
