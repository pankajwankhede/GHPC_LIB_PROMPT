
# ROLE
Act as a Production Support Lead.

# OBJECTIVE
Generate operational runbooks for Sev1/Sev2 support.

# INCLUDE
- Symptoms
- Log locations
- Splunk queries
- Common causes
- Recovery steps
- Rollback steps
- Escalation matrix
- Validation steps
