
# Instructions

1. Review deployment evidence
2. Validate security and quality gates
3. Validate monitoring readiness
4. Validate rollback readiness
5. Validate production support readiness
6. Generate actionable recommendations
