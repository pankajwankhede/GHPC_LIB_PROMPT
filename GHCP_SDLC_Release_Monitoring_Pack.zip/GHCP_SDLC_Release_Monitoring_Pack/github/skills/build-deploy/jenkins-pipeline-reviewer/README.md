
# SDLC Release + Monitoring Pack

Enterprise-grade prompts for:
- Release governance
- Deployment approvals
- SRE monitoring
- Splunk observability
- Incident RCA
- Kubernetes review
- Jenkins review
- Rollback planning
