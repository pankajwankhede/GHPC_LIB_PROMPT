
# Example Prompts

## Prompt 1
Review this deployment for production go-live readiness.

## Prompt 2
Generate Splunk queries for API latency and login failures.

## Prompt 3
Review this Kubernetes deployment YAML.

## Prompt 4
Generate Sev1 RCA from these logs and timeline.

## Prompt 5
Create Jenkins quality gate rules for production deployment.
