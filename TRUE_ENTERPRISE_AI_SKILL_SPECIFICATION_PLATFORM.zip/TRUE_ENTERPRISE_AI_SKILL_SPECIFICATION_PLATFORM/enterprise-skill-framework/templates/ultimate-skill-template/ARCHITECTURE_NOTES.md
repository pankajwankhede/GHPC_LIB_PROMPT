# Architecture Notes

- System boundaries
- Dependency constraints
- Integration points
- Scalability considerations
- Deployment topology