# Examples

## Example Prompt
Review this Spring Boot service for:
- Security
- Performance
- Technical debt
- Migration readiness

Generate:
- Findings
- Refactoring roadmap
- JUnit tests
- Jira stories