# Output Standard

Always provide:
- Executive summary
- Findings with severity
- Business impact
- Technical impact
- Remediation steps
- Refactored code examples
- Jira stories
- Final recommendation