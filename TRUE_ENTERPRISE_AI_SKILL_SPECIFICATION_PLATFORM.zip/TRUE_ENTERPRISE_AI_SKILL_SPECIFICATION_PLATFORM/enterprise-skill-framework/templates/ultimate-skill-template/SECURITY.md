# Security Considerations

- Sensitive data handling
- Secret management
- OWASP mapping
- Authentication/authorization
- Secure cookies
- CSRF/CORS