# Jira Story Template

## Title
[Skill] Fix security/performance issue

## Description
Describe issue and impact.

## Acceptance Criteria
- Tests pass
- Security validated
- Monitoring added

## Technical Tasks
- Refactor code
- Add tests
- Update configs