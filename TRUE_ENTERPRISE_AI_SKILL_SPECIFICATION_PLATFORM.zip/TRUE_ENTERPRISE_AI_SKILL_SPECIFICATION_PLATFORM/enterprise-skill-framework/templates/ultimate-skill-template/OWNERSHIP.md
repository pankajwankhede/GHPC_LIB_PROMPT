# Ownership Model

## Team Ownership
- Platform team
- Security team
- Application team

## Escalation Path
- L1 Support
- L2 Engineering
- L3 Architecture