# References

- OWASP Top 10
- Spring Boot documentation
- Kubernetes best practices
- NIST security guidance
- Internal enterprise standards