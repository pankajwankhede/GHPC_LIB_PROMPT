# Versioning

## Skill Version
1.0.0

## Compatibility
- Spring Boot 3+
- Java 17+

## Deprecation Notes
Document deprecated behavior here.