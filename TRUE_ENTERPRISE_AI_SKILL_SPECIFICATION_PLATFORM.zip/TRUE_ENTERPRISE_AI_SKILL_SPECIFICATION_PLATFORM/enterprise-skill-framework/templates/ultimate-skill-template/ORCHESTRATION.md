# Workflow Orchestration

## Upstream Skills
- Architecture review
- Security review

## Downstream Skills
- Migration review
- Deployment validation

## Invocation Rules
- If Fortify issue detected -> invoke security remediation skill
- If migration issue detected -> invoke migration skill