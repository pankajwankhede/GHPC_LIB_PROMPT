# Best Practices

- Constructor injection
- DTO/projection usage
- Structured logging
- Retry/timeout patterns
- Circuit breakers
- Pagination
- Correlation IDs
- Immutable DTOs