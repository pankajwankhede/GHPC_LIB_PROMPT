# Severity Levels

## Critical
Production outage or exploitable vulnerability.

## High
Major reliability/security issue.

## Medium
Maintainability/scalability concern.

## Low
Minor cleanup or style issue.