# Skill Name

## Goal
Define the primary objective of this skill.

## Scope
Describe what this skill covers.

## Out of Scope
Describe what this skill does NOT cover.

## When to Use
List situations where this skill should be used.

## Prerequisites
- Required inputs
- Required tools
- Required context

## Supported Inputs
- Source code
- APIs
- Logs
- YAML
- DB schema

## Unsupported Inputs
- Binary analysis
- Incomplete architecture

## What to Create
- Reports
- Refactored code
- Jira stories
- Diagrams

## Success Criteria
- Secure
- Scalable
- Maintainable
- Observable