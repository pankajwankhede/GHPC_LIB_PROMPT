# Rules

- Follow enterprise security standards.
- Preserve backward compatibility when possible.
- Avoid exposing secrets or PII.
- Prioritize maintainability and scalability.
- Validate all assumptions.