# Anti-patterns

- Big classes
- Big methods
- DB calls in loops
- Hardcoded secrets
- Generic exception swallowing
- Large payloads
- Blocking IO