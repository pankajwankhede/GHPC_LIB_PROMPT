# Reporting Style

Use:
- Clear headings
- Severity levels
- Risk scores
- Actionable recommendations
- Technical and business impact
- Production readiness comments