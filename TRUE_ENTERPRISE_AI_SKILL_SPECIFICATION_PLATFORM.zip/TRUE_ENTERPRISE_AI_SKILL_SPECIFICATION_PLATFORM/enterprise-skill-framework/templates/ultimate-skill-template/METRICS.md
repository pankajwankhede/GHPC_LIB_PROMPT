# Metrics and KPIs

- Error rate
- API latency
- JVM heap usage
- CPU usage
- Deployment success rate
- Security vulnerability count