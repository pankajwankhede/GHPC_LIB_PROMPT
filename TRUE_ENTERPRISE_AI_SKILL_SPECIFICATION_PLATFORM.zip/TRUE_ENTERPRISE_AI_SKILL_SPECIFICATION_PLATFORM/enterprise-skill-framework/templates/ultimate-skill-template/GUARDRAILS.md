# Guardrails

- Do not invent APIs/classes.
- Do not weaken security.
- Do not recommend unsafe patterns.
- Mark assumptions clearly.
- Escalate unclear or risky conditions.