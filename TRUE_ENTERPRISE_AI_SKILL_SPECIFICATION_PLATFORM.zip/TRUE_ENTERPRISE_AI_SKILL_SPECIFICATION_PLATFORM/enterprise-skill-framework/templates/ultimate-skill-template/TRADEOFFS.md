# Tradeoffs

| Option | Benefits | Risks |
|---|---|---|
| Caching | Faster response | Stale data |
| Async processing | Better scalability | Complexity |
| Event-driven | Loose coupling | Ordering issues |