# Decision Matrix

| Problem | Recommendation |
|---|---|
| Slow DB | Add indexes and optimize query |
| High memory | Streaming/batching |
| Slow API | Retry + timeout + cache |
| Security issue | Apply OWASP remediation |