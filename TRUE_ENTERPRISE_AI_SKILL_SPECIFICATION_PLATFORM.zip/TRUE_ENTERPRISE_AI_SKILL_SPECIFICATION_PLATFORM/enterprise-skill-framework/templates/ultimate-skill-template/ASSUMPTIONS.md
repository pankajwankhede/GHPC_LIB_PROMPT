# Assumptions

- Spring Boot 3+
- Kubernetes deployment
- OAuth2/JWT authentication
- Maven build
- CI/CD pipeline exists