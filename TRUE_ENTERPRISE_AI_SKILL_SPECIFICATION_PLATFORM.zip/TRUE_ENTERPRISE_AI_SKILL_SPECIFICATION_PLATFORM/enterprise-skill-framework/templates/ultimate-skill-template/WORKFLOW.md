# Step-by-Step Workflow

1. Understand the business and technical context.
2. Analyze architecture and dependencies.
3. Review security and compliance.
4. Detect technical debt and risks.
5. Validate operational readiness.
6. Generate recommendations.
7. Generate remediation actions.
8. Generate final report.