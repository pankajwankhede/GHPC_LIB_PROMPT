# Example Prompts

## API Governance
Review this OpenAPI contract for backward compatibility, versioning, pagination, error response, and security.

## Kafka/Event Streaming
Review this Kafka flow for retry, DLQ, idempotency, ordering, schema compatibility, and failure handling.

## Cache
Review this Redis/cache design for stampede, eviction, TTL, consistency, and memory risk.

## Compliance
Review this service for PCI/GDPR/privacy/audit-trail compliance.

## Platform Engineering
Create a golden path template for new Spring Boot services.

## Chaos Engineering
Generate chaos experiments for this microservice architecture.

## Cost Optimization
Review Kubernetes/cloud/logging costs and suggest optimization.

## Enterprise AI
Review this RAG/AI agent design for hallucination, prompt injection, grounding, and cost.

## Documentation
Generate architecture, runbook, onboarding, and Confluence-style documentation.

## Rules Engine
Create enterprise coding/security/logging/API/SRE rules.