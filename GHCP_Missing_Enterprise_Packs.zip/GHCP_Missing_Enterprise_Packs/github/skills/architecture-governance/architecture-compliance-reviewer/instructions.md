# Instructions

1. Understand the input.
2. Identify domain area: API, Kafka, cache, compliance, platform, cost, chaos, AI, documentation, or rules.
3. Review against enterprise standards.
4. Identify critical/high/medium/low findings.
5. Provide exact remediation.
6. Provide examples where useful.
7. Generate Jira-ready action items.
8. Provide final recommendation.