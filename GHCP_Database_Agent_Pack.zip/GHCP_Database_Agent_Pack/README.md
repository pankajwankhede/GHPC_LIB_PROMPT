# GHCP Database Agent Pack

Enterprise database agent prompts for safely connecting AI agents to databases.

Includes:
- DB agent master guardrails
- Schema analyzer
- Safe SQL generator
- Query performance reviewer
- Index strategy advisor
- Data quality profiler
- DB migration reviewer
- Flyway/Liquibase advisor
- ERD generator
- Production DB incident investigator
- PII/sensitive data guard
- DB agent orchestration
