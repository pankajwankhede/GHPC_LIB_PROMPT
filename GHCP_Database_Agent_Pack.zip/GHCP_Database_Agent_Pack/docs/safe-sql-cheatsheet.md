# Safe SQL Cheatsheet

## Safe Sample Query
```sql
SELECT column1, column2
FROM table_name
WHERE created_at >= CURRENT_DATE - INTERVAL '1 day'
FETCH FIRST 100 ROWS ONLY;
```

## Count Instead of Raw Data
```sql
SELECT status, COUNT(*) AS total
FROM transaction
WHERE created_at >= CURRENT_DATE - INTERVAL '1 day'
GROUP BY status;
```

## Mask Sensitive Data
```sql
SELECT id,
       CONCAT(SUBSTRING(email,1,2),'***') AS masked_email,
       status
FROM users
FETCH FIRST 50 ROWS ONLY;
```