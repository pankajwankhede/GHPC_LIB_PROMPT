# DB Agent Safety Policy

## Default Mode
All database agents must start in READ ONLY mode.

## Forbidden Without Explicit Approval
- DELETE
- DROP
- TRUNCATE
- ALTER
- UPDATE
- INSERT
- MERGE
- CREATE
- GRANT
- REVOKE

## Sensitive Data
Never expose raw PII, tokens, passwords, session IDs, card numbers, account numbers, JWT, or SAML assertions.

## Production Rules
- Always use time-bound filters.
- Always limit sample queries.
- Always explain impact.
- Require approval for write operations.
- Provide rollback for migrations.