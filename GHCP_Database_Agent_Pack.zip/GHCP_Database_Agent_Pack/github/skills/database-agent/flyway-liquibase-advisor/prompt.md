# Flyway / Liquibase Advisor

## Goal
Generate and review database migration files.

## Include
- Naming convention
- Versioning
- Repeatable migration guidance
- Rollback strategy
- Checksum considerations
- Environment promotion
- Validation scripts

## Output
- Migration file
- Rollback file
- Validation SQL
- Deployment notes