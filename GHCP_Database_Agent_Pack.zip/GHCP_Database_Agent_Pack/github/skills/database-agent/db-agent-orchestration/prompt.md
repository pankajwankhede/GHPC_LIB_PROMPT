# Database Agent Orchestration

## Goal
Route database requests to the correct DB skill.

## Invocation Rules
- If user asks schema → use schema-analyzer
- If user asks SQL → use sql-query-generator
- If query slow → use query-performance-reviewer
- If index issue → use index-strategy-advisor
- If data quality → use data-quality-profiler
- If migration → use db-migration-script-reviewer
- If ERD → use erd-generator
- If production issue → use production-db-incident-investigator
- If sensitive data → use pii-sensitive-data-guard

## Output
- Selected skill
- Reason
- Next steps