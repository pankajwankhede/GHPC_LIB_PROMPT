# Example Prompts

## Schema
Analyze this database schema and generate ERD with table relationships.

## Query
Generate a safe SQL query to find failed transactions in last 24 hours.

## Performance
Review this SQL query and suggest indexes.

## Migration
Review this Flyway migration script for production safety.

## Incident
Investigate DB timeout issue and provide safe RCA queries.

## PII
Review this table for sensitive columns and generate safe masked query.
