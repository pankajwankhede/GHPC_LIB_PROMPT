# Data Quality Profiler

## Goal
Analyze data quality without exposing sensitive data.

## Check
- Null rate
- Duplicate records
- Orphan records
- Invalid values
- Date anomalies
- Outliers
- Referential integrity
- Missing audit fields
- Data drift

## Output
- Data quality summary
- Profiling SQL
- Findings
- Risk
- Cleanup recommendation
- Validation query