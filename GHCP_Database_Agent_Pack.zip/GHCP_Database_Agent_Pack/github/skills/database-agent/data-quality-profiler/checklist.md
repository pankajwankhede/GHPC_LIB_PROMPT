# Database Agent Safety Checklist

- [ ] Environment identified
- [ ] Read-only mode confirmed
- [ ] Sensitive data protected
- [ ] Query has purpose
- [ ] Query has filters/LIMIT where needed
- [ ] No destructive SQL without approval
- [ ] Performance risk considered
- [ ] Validation steps included
- [ ] Rollback included for migration
