# Instructions

1. Confirm database type and environment.
2. Confirm read-only vs write access.
3. Apply safety guardrails before generating SQL.
4. Avoid exposing sensitive data.
5. Use LIMIT and filters for sample queries.
6. Explain query purpose.
7. Provide performance and risk notes.
8. Require human approval for destructive/write operations.
