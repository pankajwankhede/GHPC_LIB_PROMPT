# Production DB Incident Investigator

## Goal
Investigate DB production issues safely.

## Investigate
- Slow queries
- Blocking sessions
- Deadlocks
- High CPU
- High IO
- Connection pool exhaustion
- Lock waits
- Failed migrations
- Replication lag
- DB timeout errors

## Output
- Incident summary
- Investigation queries
- Likely root cause
- Immediate mitigation
- Permanent fix
- Monitoring improvements