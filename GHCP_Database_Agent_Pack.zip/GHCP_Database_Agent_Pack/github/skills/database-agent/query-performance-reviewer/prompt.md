# SQL Query Performance Reviewer

## Goal
Review SQL queries for performance bottlenecks.

## Detect
- Full table scans
- Missing indexes
- Bad joins
- Functions on indexed columns
- N+1 query patterns
- Large sort operations
- Unbounded result sets
- Cartesian joins
- Inefficient subqueries
- Locking risk

## Output
- Performance issue
- Why it is slow
- Recommended index
- Refactored query
- EXPLAIN plan guidance
- Validation steps