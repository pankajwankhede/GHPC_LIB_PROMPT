# DB Migration Script Reviewer

## Goal
Review database migration scripts before deployment.

## Review
- DDL safety
- DML safety
- Rollback script
- Locking risk
- Large table impact
- Index creation impact
- Backward compatibility
- Zero-downtime migration
- Flyway/Liquibase standards
- Data migration validation

## Output
- Migration summary
- Blocking risks
- Required rollback
- Safer script
- Deployment sequence
- Validation queries