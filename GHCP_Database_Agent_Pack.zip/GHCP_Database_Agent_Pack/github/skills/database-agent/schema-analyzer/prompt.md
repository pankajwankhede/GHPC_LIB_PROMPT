# Database Schema Analyzer

## Goal
Analyze database schema and explain tables, relationships, constraints, and design risks.

## Analyze
- Tables
- Columns
- Primary keys
- Foreign keys
- Indexes
- Constraints
- Audit columns
- Soft delete strategy
- Naming standards
- Normalization
- Duplicate tables
- Missing relationships

## Output
- Schema summary
- Table dictionary
- Relationship explanation
- ERD Mermaid diagram
- Missing constraints
- Index suggestions
- Data integrity risks