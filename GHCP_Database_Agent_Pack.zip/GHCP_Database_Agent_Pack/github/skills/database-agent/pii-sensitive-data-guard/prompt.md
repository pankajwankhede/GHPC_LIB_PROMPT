# PII and Sensitive Data Guard

## Goal
Prevent AI/database agent from exposing sensitive data.

## Sensitive Data
- SSN
- DOB
- Email
- Phone
- Address
- Card/account numbers
- Tokens
- Session IDs
- Passwords
- JWT/SAML assertions

## Rules
- Mask sensitive columns.
- Do not return raw sensitive values.
- Use counts/aggregates where possible.
- Use hashing/masking for samples.
- Follow privacy and compliance rules.

## Output
- Sensitive columns detected
- Masking recommendations
- Safe query version
- Compliance notes