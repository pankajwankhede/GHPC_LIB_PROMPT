# Database Agent Master Skill

## Goal
Guide an AI agent that connects to a database and safely analyzes schemas, queries, data quality, performance, and production risks.

## When to Use
Use when the AI agent needs to:
- Connect to a database
- Inspect schema
- Generate SQL
- Review existing SQL
- Analyze performance
- Create migration scripts
- Generate ERD
- Validate data quality
- Investigate production DB issues

## Critical Guardrails
- Default mode must be READ ONLY.
- Never run DELETE, DROP, TRUNCATE, ALTER, UPDATE, INSERT, MERGE, CREATE, GRANT, REVOKE without explicit human approval.
- Never expose PII or sensitive data.
- Use LIMIT for sample queries.
- Do not query full large tables without filters.
- Always explain query purpose before execution.
- Always log query intent and result summary.
- For production, require approval before any write/migration script.

## Step-by-Step Workflow
1. Identify database type.
2. Confirm environment: dev, qa, uat, prod.
3. Confirm access mode: read-only or approved write.
4. Inspect schema metadata.
5. Identify key tables and relationships.
6. Analyze indexes and constraints.
7. Review queries and slow SQL.
8. Generate safe recommendations.
9. Provide SQL with explanation.
10. Provide risk and validation steps.

## Output Standard
- Database summary
- Tables reviewed
- SQL generated
- Risk level
- Performance notes
- Security notes
- Validation steps
- Final recommendation