# Safe SQL Query Generator

## Goal
Generate safe SQL queries for analysis, reporting, troubleshooting, and validation.

## Rules
- Prefer SELECT only.
- Always add LIMIT/FETCH FIRST when sampling.
- Avoid SELECT * unless schema exploration.
- Mask sensitive fields.
- Include filters for time range and environment where possible.
- Explain each query.

## Output
- Query purpose
- SQL query
- Expected result
- Performance notes
- Risk level