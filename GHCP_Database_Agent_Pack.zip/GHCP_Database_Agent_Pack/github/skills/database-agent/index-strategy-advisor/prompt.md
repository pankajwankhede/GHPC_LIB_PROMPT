# Index Strategy Advisor

## Goal
Recommend safe indexing strategy.

## Analyze
- WHERE clauses
- JOIN columns
- ORDER BY columns
- GROUP BY columns
- Cardinality
- Composite index order
- Covering indexes
- Write overhead
- Duplicate indexes

## Output
- Current index gaps
- Recommended indexes
- Why each index is needed
- Risk of index
- Rollback script
- Validation query