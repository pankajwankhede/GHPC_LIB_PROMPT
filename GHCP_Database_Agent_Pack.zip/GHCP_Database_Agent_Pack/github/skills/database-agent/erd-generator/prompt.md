# ERD Generator

## Goal
Generate ERD from schema, JPA entities, or SQL DDL.

## Output
- Mermaid ERD
- Table relationship explanation
- PK/FK mapping
- Cardinality
- Data model notes

## Example
```mermaid
erDiagram
    CUSTOMER ||--o{ ACCOUNT : owns
    ACCOUNT ||--o{ TRANSACTION : contains
```