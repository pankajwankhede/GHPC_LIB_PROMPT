# GHCP Enterprise Diagram Generator Pack

This pack generates all major enterprise software diagrams:
- Complete project/app flow diagrams
- Controller and endpoint diagrams
- Class diagrams
- Use case diagrams
- Flowcharts
- Activity diagrams
- Sequence diagrams
- ERD/database diagrams
- Deployment/infrastructure diagrams
- Security/auth diagrams
- Microservice/event-flow diagrams
- C4 architecture diagrams
- Diagrams from code scan

Default output supports Mermaid and PlantUML so diagrams can be pasted into GitHub Markdown, Confluence, VS Code, or documentation sites.