# Instructions

1. Identify what the user wants to diagram.
2. If code is provided, extract real classes, endpoints, methods, dependencies, and relationships.
3. If requirement is provided, create logical diagrams and clearly mark assumptions.
4. Prefer Mermaid for GitHub-compatible output.
5. Provide PlantUML for class, sequence, and use case diagrams when helpful.
6. Include happy path and error path where relevant.
7. Split large diagrams into smaller diagrams.
8. Provide explanation and improvement suggestions.