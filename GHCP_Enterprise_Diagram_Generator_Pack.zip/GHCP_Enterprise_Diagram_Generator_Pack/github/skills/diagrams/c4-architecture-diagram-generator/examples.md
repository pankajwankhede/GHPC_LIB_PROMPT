# Example Prompts

## Complete Project Flow
Scan this project and generate complete app flow diagram, architecture diagram, class diagram, sequence diagram, ERD, and deployment diagram.

## Controller Diagram
Create diagram for this Spring Boot controller. Include endpoint flow, service call, repository call, DB interaction, validation, and exception handling.

## Specific Endpoint
Create sequence diagram and flowchart for POST /api/orders endpoint.

## Class Diagram
Generate class diagram for this package and explain relationships.

## Use Case Diagram
Generate use case diagram for login and user profile management.

## Security Flow
Create SAML login/logout flow diagram including browser, SP, IdP, ACS, session, and cookies.

## Microservice Flow
Create Kafka event flow diagram with producer, topic, consumer, retry, DLQ, and idempotency.

## Database ERD
Generate ERD from these JPA entities.

## Deployment Diagram
Create deployment diagram with Akamai, NGINX, Spring Boot app, database, Redis, Kafka, Splunk, and monitoring.