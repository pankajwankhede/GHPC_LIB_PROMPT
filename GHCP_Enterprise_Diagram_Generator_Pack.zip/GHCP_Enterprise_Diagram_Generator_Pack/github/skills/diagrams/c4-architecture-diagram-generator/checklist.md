# Diagram Generator Checklist

## Input Understanding
- [ ] Project flow identified
- [ ] Endpoint/controller identified
- [ ] Actors identified
- [ ] Services identified
- [ ] Database/entities identified
- [ ] External systems identified

## Diagram Coverage
- [ ] Architecture diagram
- [ ] Flow diagram
- [ ] Sequence diagram
- [ ] Class diagram
- [ ] Use case diagram
- [ ] ERD
- [ ] Deployment diagram
- [ ] Security/auth flow
- [ ] Error flow

## Quality
- [ ] Assumptions documented
- [ ] Diagram not too crowded
- [ ] Mermaid output valid
- [ ] PlantUML output valid if included
- [ ] Explanation added