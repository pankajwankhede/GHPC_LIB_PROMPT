# Diagram Prompt Cheatsheet

## Full Project
Create complete diagrams for this project:
- app flow
- architecture
- class diagram
- sequence diagram
- ERD
- deployment diagram
- security flow
- error flow

## Controller
Create controller diagram for this code:
- endpoint mapping
- request DTO
- validation
- service
- repository
- database
- exception handling
- response

## Endpoint
Create sequence diagram for endpoint:
METHOD /path

Include:
- client
- controller
- service
- repository
- external API
- DB
- success path
- error path

## Security
Create authentication flow diagram for:
- SAML/OIDC/JWT/session/cookie/logout/CORS/CSRF

## Output Format
Give Mermaid + PlantUML where possible.