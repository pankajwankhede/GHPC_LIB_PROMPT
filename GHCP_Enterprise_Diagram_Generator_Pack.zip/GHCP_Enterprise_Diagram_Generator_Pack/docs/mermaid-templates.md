# Mermaid Templates

## Flowchart
```mermaid
flowchart TD
    A[Client] --> B[Controller]
    B --> C[Service]
    C --> D[Repository]
    D --> E[(Database)]
```

## Sequence
```mermaid
sequenceDiagram
    actor Client
    participant Controller
    participant Service
    participant Repository
    participant DB
    Client->>Controller: Request
    Controller->>Service: Process
    Service->>Repository: Query
    Repository->>DB: SQL
    DB-->>Repository: Result
    Repository-->>Service: Data
    Service-->>Controller: Response
    Controller-->>Client: HTTP Response
```

## Class
```mermaid
classDiagram
    class UserController
    class UserService
    class UserRepository
    UserController --> UserService
    UserService --> UserRepository
```

## ERD
```mermaid
erDiagram
    USER ||--o{ ORDER : places
    ORDER ||--|{ ORDER_ITEM : contains
```