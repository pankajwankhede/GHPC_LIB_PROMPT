# Common Spring Boot Migration Patterns

## javax to jakarta
- javax.validation -> jakarta.validation
- javax.persistence -> jakarta.persistence
- javax.servlet -> jakarta.servlet
- javax.annotation -> jakarta.annotation

## Security
- WebSecurityConfigurerAdapter -> SecurityFilterChain bean
- antMatchers -> requestMatchers
- authorizeRequests -> authorizeHttpRequests

## Testing
- JUnit 4 -> JUnit 5
- Update Mockito and Spring Security test dependencies

## Build
- Prefer Spring Boot BOM managed versions
- Remove explicit versions when managed by BOM
- Align Spring Cloud version with Spring Boot target