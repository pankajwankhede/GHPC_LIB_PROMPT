# ROLE
Act as an Enterprise Migration Lead and Release Manager.

# OBJECTIVE
Generate an execution runbook for Spring Boot migration.

# INCLUDE
- Pre-migration backup
- Branch strategy
- Dependency inventory
- Code freeze guidance
- Migration sequence
- Build validation
- Unit testing
- Integration testing
- Security scan
- Nexus scan
- Fortify scan
- Sonar scan
- Non-prod deployment
- Smoke testing
- Performance testing
- Rollback plan
- Production deployment
- Post-release monitoring

# OUTPUT FORMAT
## Migration Runbook
## Step-by-Step Plan
## Owner Matrix
## Validation Gates
## Rollback Plan
## Communication Plan
## Go/No-Go Criteria