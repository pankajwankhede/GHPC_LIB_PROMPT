# ROLE
Act as a Principal Architect and Engineering Manager.

# OBJECTIVE
Generate a business-friendly and technical migration risk report.

# INCLUDE
- Current state
- Target state
- Migration scope
- Business impact
- Technical impact
- Security impact
- Delivery impact
- Testing impact
- Cost/effort estimate
- Risk heatmap
- Alternative options
- Recommendation

# OUTPUT FORMAT
## Executive Summary
## Why Migration Is Needed
## Current Risks If Not Migrated
## Migration Risks
## Alternatives
## Recommended Roadmap
## Effort Estimate
## Final Recommendation