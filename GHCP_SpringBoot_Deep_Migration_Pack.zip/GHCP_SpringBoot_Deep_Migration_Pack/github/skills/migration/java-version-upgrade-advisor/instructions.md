# Instructions

1. First analyze current implementation.
2. Inventory framework versions and dependencies.
3. Identify breaking changes.
4. Identify code files requiring modification.
5. Explain impact and risk before suggesting changes.
6. Provide alternatives when direct upgrade is risky.
7. Generate before/after code examples.
8. Generate Maven/Gradle upgrade plan.
9. Generate test and validation plan.
10. Generate migration roadmap and Jira stories.