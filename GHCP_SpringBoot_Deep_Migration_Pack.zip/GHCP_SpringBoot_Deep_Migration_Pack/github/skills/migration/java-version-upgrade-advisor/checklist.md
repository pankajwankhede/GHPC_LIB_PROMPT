# Spring Boot Migration Checklist

## Inventory
- [ ] Current Spring Boot version identified
- [ ] Current Java version identified
- [ ] Maven/Gradle reviewed
- [ ] Dependency tree reviewed
- [ ] Spring Security config reviewed
- [ ] JPA/Hibernate reviewed
- [ ] Tests reviewed
- [ ] CI/CD reviewed

## Code Impact
- [ ] javax to jakarta impact checked
- [ ] Deprecated APIs checked
- [ ] Removed APIs checked
- [ ] Security config changes checked
- [ ] Validation imports checked
- [ ] Servlet/JSP/JSTL impact checked
- [ ] Test impact checked

## Dependency Impact
- [ ] Spring Boot BOM alignment checked
- [ ] Spring Cloud compatibility checked
- [ ] Database driver checked
- [ ] Logging dependencies checked
- [ ] Nexus vulnerabilities checked
- [ ] Plugin versions checked

## Validation
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Security tests pass
- [ ] Fortify scan pass
- [ ] Nexus scan pass
- [ ] Sonar scan pass
- [ ] Non-prod deployment pass
- [ ] Smoke test pass