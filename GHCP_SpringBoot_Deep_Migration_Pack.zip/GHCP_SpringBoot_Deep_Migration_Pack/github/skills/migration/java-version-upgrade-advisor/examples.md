# Example Prompts

## Full Migration Impact Report
Analyze this Spring Boot project before migration. Review pom.xml, dependencies, security config, JPA, tests, and generate migration impact report with alternatives.

## Maven Migration
Review this pom.xml and suggest safe dependency changes for Spring Boot migration. Include before/after pom.xml.

## Gradle Migration
Review this build.gradle and generate safe upgrade plan with dependency compatibility risk.

## Code Modification
Review this code and identify what must change for Spring Boot migration. Provide before/after code.

## Spring Security Migration
Migrate this WebSecurityConfigurerAdapter configuration to modern SecurityFilterChain style without weakening security.

## javax to jakarta Migration
Scan this code for javax imports and provide jakarta migration plan with impact.

## Risk Report
Generate executive migration risk report with effort estimate, business impact, and recommendation.

## Jira Stories
Convert this migration impact report into Jira epic and stories.