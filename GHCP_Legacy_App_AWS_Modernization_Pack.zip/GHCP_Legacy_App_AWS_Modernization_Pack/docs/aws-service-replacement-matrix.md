# AWS Service Replacement Matrix

| Current Legacy Component | AWS Service Recommendation | Notes |
|---|---|---|
| Tomcat on VM | EC2 / Elastic Beanstalk / ECS Fargate / EKS | Choose based on control vs managed platform |
| Local file system | S3 | Object storage |
| Shared filesystem | EFS | Shared POSIX filesystem |
| Relational DB | RDS / Aurora | Managed relational database |
| JMS queue | SQS / Amazon MQ | Depends on protocol compatibility |
| Kafka | MSK | Managed Kafka |
| Local cache | ElastiCache Redis | Managed cache |
| Secrets files | Secrets Manager / SSM | Secure secret storage |
| Cron jobs | EventBridge Scheduler | Managed scheduling |
| Static assets | S3 + CloudFront | Static hosting/CDN |
| Logs | CloudWatch Logs / Splunk | Observability |