# Current State Code Scanner

## Goal
Scan legacy app code and identify migration blockers.

## Detect
- web.xml servlet/filter/listener config
- server.xml/context.xml dependencies
- JNDI datasource usage
- local file system usage
- session persistence
- hardcoded paths
- hardcoded URLs
- environment-specific configs
- old Java APIs
- javax imports
- JSP/JSTL usage
- Spring XML config
- legacy security config
- direct DB connections
- JMS usage
- cron/scheduler jobs
- local logs
- static content inside WAR

## Output
- Legacy code inventory
- Migration blockers
- Code change required
- AWS target mapping
- Refactoring priority