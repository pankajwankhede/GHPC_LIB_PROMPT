# Legacy App to AWS Modernization Master Skill

## Goal
Scan a legacy application and generate a complete AWS migration/modernization report.

## When to Use
Use when:
- Legacy app runs on Tomcat/WebLogic/JBoss/VM
- App needs migration to AWS
- App needs modernization to latest Java/Spring Boot
- App uses old services/configs that can be replaced by AWS managed services
- Team needs code-level + infrastructure-level impact report

## Inputs
- Source code
- pom.xml / build.gradle
- web.xml
- server.xml / context.xml
- application.properties/yml
- logback/log4j config
- DB configs
- JMS/Kafka configs
- File storage configs
- Cache configs
- Auth configs
- Deployment scripts
- Tomcat configs
- Infra diagrams
- Current monitoring dashboards
- Firewall/DNS details

## Analyze Current State
- Runtime: Tomcat/WebLogic/JBoss/PCF/VM
- Java version
- Framework version
- Servlet/JSP/JSTL usage
- Spring/Spring Boot usage
- Database usage
- File storage usage
- Messaging usage
- Cache usage
- Scheduler/batch jobs
- Authentication/SSO
- Logging/monitoring
- External integrations
- Config/secrets
- CI/CD pipeline

## AWS Target Recommendations
Map legacy components to AWS options:
- Tomcat app -> Elastic Beanstalk, ECS Fargate, EKS, EC2, App Runner
- Database -> Amazon RDS / Aurora
- File storage -> Amazon S3
- Shared file mount -> Amazon EFS
- JMS/queues -> Amazon SQS / Amazon MQ
- Kafka -> Amazon MSK
- Cache -> Amazon ElastiCache / MemoryDB
- Secrets -> AWS Secrets Manager / SSM Parameter Store
- Config -> AWS AppConfig / SSM Parameter Store
- Logs -> CloudWatch Logs / OpenSearch / Splunk integration
- Scheduler -> EventBridge Scheduler / AWS Batch
- Static content -> S3 + CloudFront
- API gateway -> Amazon API Gateway / ALB
- Auth -> Amazon Cognito / IAM / existing enterprise IdP integration
- WAF/security -> AWS WAF / Shield / Security Groups / NACLs

## Output
1. Executive Summary
2. Current State Inventory
3. AWS Target Architecture
4. Service Replacement Matrix
5. Code Impact Report
6. Config Impact Report
7. Infra Impact Report
8. Security Impact Report
9. Database Impact Report
10. CI/CD Impact Report
11. Monitoring Impact Report
12. Migration Roadmap
13. Risk Matrix
14. Cost Considerations
15. Rollback Plan
16. Jira Stories
17. Production Readiness Score