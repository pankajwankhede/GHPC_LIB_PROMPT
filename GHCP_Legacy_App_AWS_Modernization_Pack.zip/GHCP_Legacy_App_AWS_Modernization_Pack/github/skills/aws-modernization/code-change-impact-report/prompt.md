# Code Change Impact Report

## Goal
Generate code-level changes required for AWS migration.

## Analyze
- File IO changes
- DB connection changes
- Secrets/config access
- Session handling
- Static content handling
- Logging changes
- Health endpoint changes
- Cloud-native readiness
- Container readiness
- Dependency upgrades
- Environment variables
- IAM-based access

## Output
| File/Class | Current Pattern | AWS Impact | Required Change | Risk |
|---|---|---|---|---|

## Code Examples
Provide before/after code for:
- S3 file access
- Secrets Manager usage
- RDS datasource config
- CloudWatch structured logs
- Health checks