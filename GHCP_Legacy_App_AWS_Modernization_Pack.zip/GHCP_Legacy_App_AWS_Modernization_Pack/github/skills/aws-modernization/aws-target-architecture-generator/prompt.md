# AWS Target Architecture Generator

## Goal
Generate AWS target architecture for legacy app modernization.

## Architecture Options
- Rehost: EC2 + Tomcat
- Replatform: Elastic Beanstalk
- Containerize: ECS Fargate
- Kubernetes: EKS
- Serverless partial modernization: Lambda/EventBridge/SQS
- Static + API split: CloudFront/S3 + ECS/API Gateway

## Output
- Recommended target architecture
- Mermaid diagram
- Component table
- Security boundaries
- Network design
- HA/DR design
- Monitoring design
- Cost considerations