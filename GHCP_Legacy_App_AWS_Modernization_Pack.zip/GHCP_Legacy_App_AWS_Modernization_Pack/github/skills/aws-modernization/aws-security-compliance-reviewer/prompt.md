# AWS Security and Compliance Reviewer

## Goal
Review AWS migration for security and compliance.

## Analyze
- IAM least privilege
- Secrets handling
- Encryption at rest/in transit
- Security groups
- WAF
- TLS/certs
- Logging/audit trail
- PII handling
- PCI/GDPR/internal compliance
- Vulnerability scans
- Container image scanning

## Output
- Security impact report
- Compliance mapping
- Required controls
- Risks
- Remediation