# AWS Service Replacement Matrix

## Goal
Identify legacy services/configurations and recommend AWS managed service replacements.

## Replacement Examples
| Legacy Component | AWS Service Option |
|---|---|
| Local files | Amazon S3 |
| Shared files | Amazon EFS |
| JNDI datasource | Amazon RDS/Aurora + Secrets Manager |
| JMS queue | Amazon SQS / Amazon MQ |
| Kafka | Amazon MSK |
| Ehcache/local cache | ElastiCache Redis |
| Cron jobs | EventBridge Scheduler |
| Batch jobs | AWS Batch / ECS Scheduled Tasks |
| Local secrets | Secrets Manager / SSM Parameter Store |
| Local config | AWS AppConfig / SSM Parameter Store |
| Local logs | CloudWatch Logs / Splunk Forwarder |
| Static assets | S3 + CloudFront |
| API gateway/proxy | API Gateway / ALB |
| WAF/security | AWS WAF |
| Authentication | Cognito or enterprise IdP integration |

## Output
- Current service
- AWS replacement
- Code change
- Infra change
- Migration risk
- Cost consideration
- Recommended approach