# AWS Observability and Monitoring Advisor

## Goal
Create monitoring strategy for migrated AWS app.

## Include
- CloudWatch metrics/logs
- X-Ray tracing
- ALB metrics
- ECS/EKS metrics
- RDS metrics
- S3 access logs
- WAF logs
- Splunk integration
- Alert thresholds
- Dashboards
- Runbooks

## Output
- Monitoring plan
- Dashboard requirements
- Alert rules
- RCA queries
- Support handover