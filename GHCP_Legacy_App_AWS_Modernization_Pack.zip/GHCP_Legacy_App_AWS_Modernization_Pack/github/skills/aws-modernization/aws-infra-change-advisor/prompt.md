# AWS Infrastructure Change Advisor

## Goal
Generate AWS-side infrastructure changes required for migration.

## Analyze/Create
- VPC/subnets
- Security groups
- Load balancer
- ECS/EKS/Beanstalk/EC2
- RDS/Aurora
- S3/EFS
- Secrets Manager
- CloudWatch
- IAM roles/policies
- API Gateway/ALB
- Route 53/DNS
- ACM certificates
- WAF
- CI/CD roles
- Network firewall/connectivity

## Output
- Infra component list
- Terraform/CloudFormation guidance
- IAM requirements
- Security risks
- Network requirements
- Firewall requirements