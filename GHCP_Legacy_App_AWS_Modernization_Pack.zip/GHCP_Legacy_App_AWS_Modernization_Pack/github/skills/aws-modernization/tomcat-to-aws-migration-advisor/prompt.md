# Tomcat to AWS Migration Advisor

## Goal
Generate migration plan for Tomcat-hosted Java apps to AWS.

## AWS Target Options
- EC2 + Tomcat for quick rehost
- Elastic Beanstalk for managed Tomcat platform
- ECS Fargate for containerized deployment
- EKS for Kubernetes-based enterprise platform
- App Runner for simple containerized web apps

## Decision Matrix
| Current Need | AWS Option |
|---|---|
| Fast lift-and-shift | EC2 or Elastic Beanstalk |
| Container modernization | ECS Fargate |
| Enterprise Kubernetes standard | EKS |
| Simple managed container web app | App Runner |
| Full control | EC2 |

## Analyze
- WAR packaging
- Tomcat version
- JNDI resources
- Servlet filters
- Session handling
- SSL/certs
- Thread pool configs
- Connector configs
- Log configs

## Output
- Recommended AWS compute option
- Required code changes
- Required Tomcat/config changes
- Containerization plan
- Deployment plan
- Rollback plan