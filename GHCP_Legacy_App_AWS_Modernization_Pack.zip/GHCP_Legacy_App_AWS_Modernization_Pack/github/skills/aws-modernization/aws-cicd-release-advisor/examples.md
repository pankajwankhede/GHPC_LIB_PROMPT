# Example Prompts

## Full Legacy App to AWS Report
Scan this legacy Tomcat Java app and generate a full AWS modernization report. Include current state, target architecture, AWS service replacement matrix, code changes, infra changes, security impact, monitoring plan, and Jira stories.

## Tomcat to AWS
Analyze this Tomcat app and recommend whether to use EC2, Elastic Beanstalk, ECS Fargate, EKS, or App Runner. Provide pros/cons and code/config impact.

## Service Replacement
Scan this project and identify services/configs that can be replaced by AWS services such as S3, RDS, SQS, MSK, ElastiCache, Secrets Manager, CloudWatch, API Gateway, WAF.

## Code Impact
Analyze this code for local filesystem, JNDI, hardcoded config, local session, JMS, scheduler, and logging patterns. Provide AWS migration changes.

## Target Architecture
Generate AWS target architecture diagram for this app using ECS Fargate, ALB, RDS, S3, Secrets Manager, CloudWatch, and Splunk.
