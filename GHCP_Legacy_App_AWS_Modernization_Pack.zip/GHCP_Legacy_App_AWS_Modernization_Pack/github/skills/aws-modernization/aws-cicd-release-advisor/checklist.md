# AWS Modernization Checklist

- [ ] Current runtime identified
- [ ] Java/framework version identified
- [ ] Tomcat/config files reviewed
- [ ] DB usage reviewed
- [ ] File storage reviewed
- [ ] Messaging reviewed
- [ ] Cache reviewed
- [ ] Auth reviewed
- [ ] Secrets/config reviewed
- [ ] AWS service mapping created
- [ ] Code changes identified
- [ ] Infra changes identified
- [ ] CI/CD changes identified
- [ ] Monitoring plan created
- [ ] Rollback plan created
