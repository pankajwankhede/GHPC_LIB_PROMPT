# AWS CI/CD Release Advisor

## Goal
Generate CI/CD and release plan for AWS migration.

## Include
- Build artifact strategy
- Docker image strategy
- ECR
- CodeBuild/CodePipeline/GitHub Actions/Jenkins
- Security scans
- Deployment approvals
- Blue/green or canary
- Rollback
- Smoke tests
- Monitoring validation
- Release evidence

## Output
- Pipeline stages
- Quality gates
- Rollback plan
- Deployment checklist
- RTS handover content