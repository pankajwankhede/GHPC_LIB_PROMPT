# Instructions

1. Scan current app code, configs, dependencies, and runtime.
2. Identify legacy patterns and service usage.
3. Map current components to AWS target services.
4. Generate code-level and AWS-side changes.
5. Create target architecture and migration roadmap.
6. Include security, compliance, observability, CI/CD, rollback, and support impact.
7. Generate Jira-ready stories.
