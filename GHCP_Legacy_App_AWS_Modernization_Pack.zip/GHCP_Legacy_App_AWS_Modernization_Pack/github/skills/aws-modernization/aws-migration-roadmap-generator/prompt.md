# AWS Migration Roadmap Generator

## Goal
Create phased migration roadmap.

## Phases
1. Discovery and inventory
2. Current state assessment
3. AWS target architecture
4. Code remediation
5. Dependency modernization
6. Containerization or platform setup
7. Infra provisioning
8. CI/CD update
9. Data migration
10. Non-prod deployment
11. Security validation
12. Performance validation
13. Cutover
14. Monitoring
15. RTS handover

## Output
- Phase-wise roadmap
- Activities
- Owners
- Risks
- Exit criteria
- Jira epics/stories