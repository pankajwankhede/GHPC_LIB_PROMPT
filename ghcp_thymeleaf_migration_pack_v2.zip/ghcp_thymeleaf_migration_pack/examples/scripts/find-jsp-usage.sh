#!/usr/bin/env bash
set -euo pipefail
ROOT=${1:-.}
echo "Scanning JSP/JSTL usage under $ROOT"
grep -RIn --include='*.jsp' -E '<c:|<fmt:|<fn:|<form:|<jsp:include|<%|pageContext|requestScope|sessionScope' "$ROOT" || true
