<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html>
<body>
<c:if test="${user.active}">
    <h1>${user.name}</h1>
</c:if>
<table>
<c:forEach var="role" items="${roles}">
    <tr><td>${role.name}</td></tr>
</c:forEach>
</table>
<a href="${pageContext.request.contextPath}/user/list">Back</a>
</body>
</html>
