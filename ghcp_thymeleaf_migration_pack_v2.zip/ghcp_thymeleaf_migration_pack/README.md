# GHCP JSP to Thymeleaf Migration Pack

Purpose: Help GitHub Copilot / AI Agent migrate Spring Boot MVC JSP + JSTL pages to Thymeleaf with minimum backend changes.

Target stack:
- Java 17+
- Spring Boot 3.x
- Spring MVC
- Existing JSP views using JSTL
- Migration target: Thymeleaf templates

Main goals:
1. Replace JSP/JSTL dependency usage.
2. Keep existing controllers and model attributes unchanged where possible.
3. Convert JSP view files to Thymeleaf HTML templates.
4. Preserve UI behavior, form binding, validation errors, URLs, fragments, and security behavior.
5. Avoid big-bang migration; migrate page-by-page.

Suggested agent flow:
1. Scan JSP file.
2. Identify JSTL tags, scriptlets, Spring form tags, includes, URLs, and model attributes.
3. Generate Thymeleaf equivalent HTML.
4. Keep controller return view name same where possible.
5. Add tests or smoke checklist.
6. Remove JSP/JSTL dependencies only after all pages are migrated.

## New Prompt Added

- `prompts/05-remove-jsp-viewresolver-add-thymeleaf.prompt.md`

Use this prompt when asking GitHub Copilot Agent to update project configuration:
- Add Gradle/Maven Thymeleaf dependency
- Remove JSP ViewResolver
- Remove JSP MVC prefix/suffix properties
- Add Thymeleaf template resolver properties
- Preserve controller logical view names
- Remove JSP/JSTL dependencies after full migration

## New Guide Added

- `docs/viewresolver-and-gradle-migration.md`
