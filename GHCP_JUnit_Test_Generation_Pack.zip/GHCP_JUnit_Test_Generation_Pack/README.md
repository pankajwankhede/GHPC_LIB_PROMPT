# GHCP JUnit Test Generation Pack

Separate enterprise-grade pack for generating Java/Spring Boot tests.

Includes:
- Master JUnit test generation skill
- Service layer Mockito tests
- Controller MockMvc tests
- Repository integration tests
- Exception handler tests
- Security tests
- WebClient/REST client tests
- Kafka tests
- Parameterized edge case tests
- Coverage gap analyzer
- GitHub Copilot JUnit agent prompt
