# JUnit Copilot Usage Guide

## Best Prompt
Use junit-test-generation-master.

Analyze this class and generate:
- JUnit 5 tests
- Mockito setup
- Happy path
- Negative path
- Exception path
- Boundary cases
- Null handling
- Coverage gaps

## Controller Prompt
Use controller-mockmvc-test-generator for this controller.

## Service Prompt
Use service-layer-junit-generator for this service.

## Repository Prompt
Use repository-integration-test-generator for this repository.

## Security Prompt
Use security-junit-test-generator for this security config/controller.