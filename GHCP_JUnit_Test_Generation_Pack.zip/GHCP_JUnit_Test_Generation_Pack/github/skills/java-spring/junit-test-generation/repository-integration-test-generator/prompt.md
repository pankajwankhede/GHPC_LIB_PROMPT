# Repository Integration Test Generator

## Goal
Generate JPA repository integration tests.

## Analyze
- Entity mapping
- Repository methods
- Custom queries
- Native queries
- Transaction behavior
- Constraints
- Index-sensitive queries

## Generate Tests
- Save and fetch
- Custom query validation
- Empty result
- Constraint violation
- Relationship mapping
- Transaction behavior

## Preferred Tools
- @DataJpaTest
- Testcontainers when real DB behavior matters
- Flyway/Liquibase migration validation

## Output
Repository test class with setup data and assertions.