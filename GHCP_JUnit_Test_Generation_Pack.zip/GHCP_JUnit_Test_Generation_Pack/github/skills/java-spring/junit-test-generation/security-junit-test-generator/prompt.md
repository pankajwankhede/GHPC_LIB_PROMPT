# Security Test Generator

## Goal
Generate Spring Security tests.

## Analyze
- Authentication requirements
- Authorization roles
- Method security
- JWT/OIDC/SAML behavior
- CSRF requirements
- CORS behavior
- Session/cookie rules

## Generate Tests
- Anonymous access denied
- Authenticated access allowed
- Role-based access
- Forbidden access
- CSRF required/disabled behavior
- JWT invalid/expired token behavior

## Tools
- spring-security-test
- @WithMockUser
- SecurityMockMvcRequestPostProcessors