# Parameterized and Edge Case Test Generator

## Goal
Generate parameterized tests for boundary and edge cases.

## Use For
- Validation rules
- Utility methods
- Mapping logic
- Business rules
- Date/time rules
- Calculation logic

## Generate
- @ParameterizedTest
- @CsvSource
- @MethodSource
- Boundary values
- Null/empty cases
- Invalid values