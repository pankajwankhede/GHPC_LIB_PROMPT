# Example Prompts

## Service Test
Use service-layer-junit-generator. Generate JUnit 5 + Mockito tests for this service class covering happy path, negative path, exceptions, and repository interaction verification.

## Controller Test
Use controller-mockmvc-test-generator. Generate MockMvc tests for this controller covering 200, 400, 401, 403, 404, and exception responses.

## Repository Test
Use repository-integration-test-generator. Generate @DataJpaTest for this repository and validate custom queries.

## Security Test
Use security-junit-test-generator. Generate tests for role-based access and unauthorized access.

## Coverage Gap
Use test-coverage-gap-analyzer. Review existing tests and identify missing scenarios.
