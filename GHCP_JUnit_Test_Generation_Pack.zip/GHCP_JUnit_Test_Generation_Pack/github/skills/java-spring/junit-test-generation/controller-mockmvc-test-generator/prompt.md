# Controller MockMvc Test Generator

## Goal
Generate Spring MVC controller tests using MockMvc.

## Analyze
- Endpoint mappings
- HTTP methods
- Request DTO validation
- Response DTO
- Status codes
- Headers
- Security rules
- Exception mapping
- Error response format

## Generate Tests
- 200 OK / 201 Created
- 400 Bad Request validation
- 401 Unauthorized
- 403 Forbidden
- 404 Not Found
- 500 mapped error
- Request body validation
- Header validation

## Required Patterns
- @WebMvcTest
- @MockBean service
- MockMvc
- ObjectMapper
- jsonPath assertions

## Output
Complete controller test class with JSON request/response validation.