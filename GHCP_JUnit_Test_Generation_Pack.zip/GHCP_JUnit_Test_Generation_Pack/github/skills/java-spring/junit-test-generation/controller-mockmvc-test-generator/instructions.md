# Instructions

1. Understand the class under test.
2. Identify dependencies and behavior.
3. Select correct test type: unit, controller, repository, integration, security.
4. Generate meaningful tests.
5. Cover happy, negative, exception, and edge cases.
6. Use Mockito/MockMvc/Testcontainers only when appropriate.
7. Add strong assertions.
8. Verify interactions where useful.
9. Report coverage gaps.
