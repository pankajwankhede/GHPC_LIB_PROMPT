# JUnit Test Generation Checklist

- [ ] JUnit 5 used
- [ ] Mockito used correctly
- [ ] Class under test is not mocked
- [ ] Happy path covered
- [ ] Negative path covered
- [ ] Exception path covered
- [ ] Boundary cases covered
- [ ] Null/empty input covered
- [ ] Security tests added if needed
- [ ] Strong assertions used
- [ ] verify() used where useful
- [ ] No flaky tests
- [ ] Coverage gaps reported
