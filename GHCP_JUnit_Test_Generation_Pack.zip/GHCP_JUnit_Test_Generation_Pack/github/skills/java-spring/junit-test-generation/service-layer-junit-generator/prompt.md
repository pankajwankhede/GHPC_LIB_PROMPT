# Service Layer JUnit Generator

## Goal
Generate Mockito-based unit tests for Spring service classes.

## Analyze
- Business logic
- Dependency calls
- Repository interactions
- External client calls
- Validation logic
- Exception handling
- Transaction behavior

## Generate Tests
- Happy path
- Not found scenario
- Invalid input
- Repository exception
- External service exception
- Null/empty input
- Boundary cases
- Verify repository/client calls

## Example Prompt
Generate JUnit 5 + Mockito tests for this service class. Cover happy path, negative path, exception path, null handling, and verify interactions.

## Output
- @ExtendWith(MockitoExtension.class)
- @Mock dependencies
- @InjectMocks service
- test data builders
- assertThat/assertThrows
- verify calls