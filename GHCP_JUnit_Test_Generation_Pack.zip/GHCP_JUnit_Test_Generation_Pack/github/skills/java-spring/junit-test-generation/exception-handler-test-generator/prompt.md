# Exception Handler Test Generator

## Goal
Generate tests for @ControllerAdvice and exception handling.

## Analyze
- Custom exceptions
- Error response body
- HTTP status mapping
- Error codes
- Validation errors
- Sensitive data exposure

## Generate Tests
- Business exception
- Validation exception
- Access denied
- Authentication error
- Generic safe error
- No stack trace in response

## Output
MockMvc tests or direct handler tests with safe error response validation.