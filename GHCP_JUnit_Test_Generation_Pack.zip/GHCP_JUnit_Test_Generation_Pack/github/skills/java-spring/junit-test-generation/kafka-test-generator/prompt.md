# Kafka Test Generator

## Goal
Generate tests for Kafka producers and consumers.

## Analyze
- Topic names
- Message schema
- Serialization/deserialization
- Retry behavior
- DLQ behavior
- Idempotency
- Error handling

## Generate Tests
- Producer sends correct event
- Consumer processes event
- Invalid event handled
- Retry scenario
- DLQ scenario
- Duplicate event ignored

## Tools
- Mockito
- EmbeddedKafka
- Testcontainers Kafka