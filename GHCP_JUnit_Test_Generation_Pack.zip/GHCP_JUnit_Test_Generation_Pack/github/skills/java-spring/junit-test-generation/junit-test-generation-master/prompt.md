# JUnit Test Generation Master Skill

## Goal
Generate enterprise-grade JUnit 5 test cases for Java/Spring Boot applications.

## When to Use
Use this skill when:
- Creating new tests
- Improving test coverage
- Reviewing PR test gaps
- Refactoring legacy code
- Validating migration changes
- Covering bug fixes
- Creating regression tests

## Prerequisites
Required inputs:
- Java class under test
- Related dependencies/interfaces
- Expected business behavior
- Exception scenarios
- Existing test class if available

## What to Create
- JUnit 5 test classes
- Mockito unit tests
- MockMvc controller tests
- Repository integration tests
- Security tests
- Exception tests
- Parameterized tests
- Test data builders
- Coverage gap report

## Step-by-Step Workflow
1. Understand class responsibility.
2. Identify public methods.
3. Identify dependencies.
4. Identify happy path.
5. Identify negative paths.
6. Identify exception paths.
7. Identify boundary conditions.
8. Create mock setup.
9. Generate test methods.
10. Add meaningful assertions.
11. Verify interactions.
12. Suggest missing production-code improvements.

## Output Standard
Provide:
- Complete test class
- Imports
- Mockito setup
- Test data
- Assertions
- Coverage notes
- Run command
- Missing test scenarios

## Guardrails
- Do not test private methods directly.
- Do not mock the class under test.
- Do not overuse Spring context for simple unit tests.
- Do not write flaky tests.
- Do not assert only non-null.
- Avoid testing framework behavior.