# WebClient / REST Client Test Generator

## Goal
Generate tests for outbound HTTP clients.

## Analyze
- Request URL
- Headers
- Auth headers
- Timeout behavior
- Retry behavior
- Error mapping
- Response parsing

## Generate Tests
- Success response
- 4xx mapping
- 5xx mapping
- Timeout
- Retry
- Empty response
- Invalid JSON

## Tools
- MockWebServer
- WireMock
- Mockito