# RTS Checklist

- [ ] Jira stories linked
- [ ] PR details documented
- [ ] Architecture updated
- [ ] APIs documented
- [ ] DB changes documented
- [ ] Security review complete
- [ ] Fortify reviewed
- [ ] Nexus reviewed
- [ ] Deployment steps documented
- [ ] Rollback plan documented
- [ ] Splunk dashboards updated
- [ ] Alerts configured
- [ ] Support team informed
- [ ] Release readiness approved